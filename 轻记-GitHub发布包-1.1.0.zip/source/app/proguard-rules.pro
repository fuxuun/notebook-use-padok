# Room and Jetpack Ink publish the consumer rules their implementations require.
