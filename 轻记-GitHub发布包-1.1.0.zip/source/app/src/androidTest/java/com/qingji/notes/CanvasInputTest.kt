package com.qingji.notes

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.SystemClock
import android.view.InputDevice
import android.view.MotionEvent
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class CanvasInputTest {
    @Test fun stylusCommitsAndUndoRestoresWhileFingerAndCancelledStrokesDoNotWrite() {
        InstrumentationRegistry.getInstrumentation().runOnMainSync {
            val context = ApplicationProvider.getApplicationContext<Context>()
            val content = PageContent(PageEntity(notebookId = "input-test", position = 0))
            var latest = content
            val view = NoteCanvasView(context)
            view.layout(0, 0, 800, 1000)
            view.setPage(content, null)
            view.setSettings(EditorSettings())
            view.fitPage()
            view.onContentChanged = { latest = it }
            gesture(view, MotionEvent.TOOL_TYPE_FINGER)
            assertTrue(latest.strokes.isEmpty())
            // The finger gesture pans the paper; start the pen check from a known viewport.
            view.fitPage()
            gesture(view, MotionEvent.TOOL_TYPE_STYLUS)
            assertEquals(1, latest.strokes.size)
            InkSupport.validate(latest.strokes.single())
            view.undo()
            assertTrue(latest.strokes.isEmpty())
            view.redo()
            assertEquals(1, latest.strokes.size)
            gesture(view, MotionEvent.TOOL_TYPE_STYLUS, cancel = true)
            assertEquals("Palm cancellation must discard the unfinished stroke", 1, latest.strokes.size)
        }
    }

    @Test fun crossingThePaperEdgePreservesOutsidePointsAndClipsTheirRendering() {
        InstrumentationRegistry.getInstrumentation().runOnMainSync {
            val context = ApplicationProvider.getApplicationContext<Context>()
            val content = PageContent(PageEntity(notebookId = "edge-test", position = 0, width = 600f, height = 600f))
            var latest = content
            val view = NoteCanvasView(context)
            view.layout(0, 0, 1000, 1000)
            view.setPage(content, null)
            view.setSettings(EditorSettings())
            view.fitPage()
            view.onContentChanged = { latest = it }
            val margin = 20f * context.resources.displayMetrics.density
            val scale = (1000f - 2f * margin) / 600f
            val outsideX = 600f + margin / (2f * scale)
            val pagePoints = listOf(580f to 200f, outsideX to 200f, outsideX to 400f, 580f to 400f)
            val screenPoints = pagePoints.map { (x, y) -> margin + x * scale to margin + y * scale }
            val bitmap = Bitmap.createBitmap(1000, 1000, Bitmap.Config.ARGB_8888)
            try {
                val canvas = Canvas(bitmap)
                val sampleX = (margin + outsideX * scale).toInt()
                val sampleY = (margin + 300f * scale).toInt()
                view.draw(canvas)
                val paperSurround = bitmap.getPixel(sampleX, sampleY)
                gesture(view, MotionEvent.TOOL_TYPE_STYLUS, points = screenPoints)
                val restored = InkSupport.decode(latest.strokes.single()).inputs
                assertEquals(pagePoints.size, restored.size)
                for (i in pagePoints.indices) {
                    assertEquals(pagePoints[i].first, restored[i].x, 0.1f)
                    assertEquals(pagePoints[i].second, restored[i].y, 0.1f)
                }
                assertTrue("Off-page movement must not become a line on the paper edge", restored[1].x > content.page.width)
                view.draw(canvas)
                assertEquals("Off-page ink must remain clipped", paperSurround, bitmap.getPixel(sampleX, sampleY))
            } finally {
                bitmap.recycle()
            }
        }
    }

    private fun gesture(
        view: NoteCanvasView,
        toolType: Int,
        cancel: Boolean = false,
        points: List<Pair<Float, Float>> = listOf(200f to 300f, 260f to 300f, 320f to 300f),
    ) {
        val start = SystemClock.uptimeMillis()
        points.forEachIndexed { i, (x, y) ->
            val action = when (i) {
                0 -> MotionEvent.ACTION_DOWN
                points.lastIndex -> if (cancel) MotionEvent.ACTION_CANCEL else MotionEvent.ACTION_UP
                else -> MotionEvent.ACTION_MOVE
            }
            val properties = MotionEvent.PointerProperties().apply { id = 0; this.toolType = toolType }
            val coordinates = MotionEvent.PointerCoords().apply { this.x = x; this.y = y; pressure = (0.5f + i * 0.2f).coerceAtMost(1f); size = 0.1f }
            val event = MotionEvent.obtain(start, start + i * 20, action, 1, arrayOf(properties), arrayOf(coordinates), 0, 0, 1f, 1f, 0, 0, if (toolType == MotionEvent.TOOL_TYPE_STYLUS) InputDevice.SOURCE_STYLUS else InputDevice.SOURCE_TOUCHSCREEN, 0)
            view.onTouchEvent(event)
            event.recycle()
        }
    }
}
