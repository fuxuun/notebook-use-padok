package com.qingji.notes

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import androidx.ink.brush.InputToolType
import androidx.ink.strokes.MutableStrokeInputBatch
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class InkRoundTripTest {
    @Test fun encodedStrokeRetainsPageCoordinatesAndPressure() {
        val inputs = MutableStrokeInputBatch()
            .add(InputToolType.STYLUS, 42f, 60f, 0L, pressure = 0.25f)
            .add(InputToolType.STYLUS, 92f, 100f, 20L, pressure = 0.9f)
        val entity = StrokeEntity(pageId = "page", position = 0, brush = InkSupport.PEN, color = 0xFF25332FL, size = 3f, inputs = InkSupport.encode(inputs))
        InkSupport.validate(entity)
        val restored = InkSupport.decode(entity)
        assertEquals(2, restored.inputs.size)
        assertEquals(42f, restored.inputs[0].x, 0.01f)
        assertEquals(100f, restored.inputs[1].y, 0.01f)
        assertEquals(0.9f, restored.inputs[1].pressure, 0.01f)
        assertEquals(3f, restored.brush.size, 0.001f)
    }

    @Test fun exportedHighlighterRemainsTranslucentOnSoftwareCanvas() {
        val inputs = MutableStrokeInputBatch()
        for (step in 0..10) inputs.add(InputToolType.STYLUS, 20f + step * 10f, 50f, step * 10L, pressure = 0.5f)
        val entity = StrokeEntity(pageId = "page", position = 0, brush = InkSupport.HIGHLIGHTER, color = 0x55FF0000L, size = 20f, inputs = InkSupport.encode(inputs))
        val bitmap = Bitmap.createBitmap(300, 200, Bitmap.Config.ARGB_8888)
        try {
            val canvas = Canvas(bitmap)
            canvas.drawColor(Color.WHITE)
            canvas.scale(2f, 2f)
            InkSupport.drawStrokes(canvas, listOf(entity))
            val pixels = IntArray(bitmap.width * bitmap.height)
            bitmap.getPixels(pixels, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)
            val painted = pixels.filter { Color.green(it) < 250 }
            assertTrue("The software PDF path must render the stroke", painted.isNotEmpty())
            assertTrue("A highlighter must not cover the page with opaque red", painted.all { Color.green(it) > 100 })
        } finally {
            bitmap.recycle()
        }
    }
}
