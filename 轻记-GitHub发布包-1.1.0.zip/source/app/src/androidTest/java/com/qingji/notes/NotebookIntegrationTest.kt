package com.qingji.notes

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import androidx.ink.brush.InputToolType
import androidx.ink.storage.encode
import androidx.ink.strokes.MutableStrokeInputBatch
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import java.io.ByteArrayOutputStream
import java.io.File
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class NotebookIntegrationTest {
    private lateinit var context: Context
    private lateinit var db: NoteDatabase
    private lateinit var repository: NoteRepository
    private val temporaryFiles = mutableListOf<File>()

    @Before fun setup() {
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, NoteDatabase::class.java).build()
        repository = NoteRepository(context, db)
    }

    @After fun cleanup() {
        db.close()
        temporaryFiles.forEach { it.delete() }
    }

    @Test fun editableInkSurvivesSaveBackupRestoreAndPdfExport() = runBlocking {
        val notebookId = repository.createNotebook("完整流程验证", "blank")
        val page = repository.observePages(notebookId).first().single()
        val inputs = MutableStrokeInputBatch().apply {
            add(InputToolType.STYLUS, 60f, 100f, 0L, pressure = 0.5f)
            add(InputToolType.STYLUS, 160f, 100f, 100L, pressure = 0.8f)
            add(InputToolType.STYLUS, 260f, 100f, 200L, pressure = 1f)
        }
        val encoded = ByteArrayOutputStream().also { inputs.encode(it) }.toByteArray()
        val stroke = StrokeEntity(pageId = page.id, position = 0, brush = "pressure-v1", color = 0xFF000000L, size = 8f, inputs = encoded)
        val box = TextBoxEntity(pageId = page.id, position = 0, text = "保留可编辑文字", x = 60f, y = 150f)
        repository.savePage(PageContent(page, listOf(stroke), listOf(box)))
        val saved = repository.loadPage(page.id)
        assertArrayEquals(encoded, saved.strokes.single().inputs)
        assertEquals(box.text, saved.textBoxes.single().text)

        val bitmap = Bitmap.createBitmap(595, 842, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)
        InkSupport.drawStrokes(canvas, saved.strokes)
        assertNotEquals("Software Canvas must contain exported ink", Color.WHITE, bitmap.getPixel(160, 100))
        bitmap.recycle()

        val pdf = temporary("export", ".pdf")
        repository.exportPdf(notebookId, Uri.fromFile(pdf))
        ParcelFileDescriptor.open(pdf, ParcelFileDescriptor.MODE_READ_ONLY).use { descriptor ->
            PdfRenderer(descriptor).use { renderer ->
                assertEquals(1, renderer.pageCount)
                renderer.openPage(0).use { exported ->
                    assertEquals(595, exported.width)
                    assertEquals(842, exported.height)
                    val rendered = Bitmap.createBitmap(595, 842, Bitmap.Config.ARGB_8888)
                    exported.render(rendered, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    assertTrue(Color.red(rendered.getPixel(160, 100)) < 200)
                    rendered.recycle()
                }
            }
        }

        val zip = temporary("backup", ".zip")
        repository.backup(Uri.fromFile(zip))
        assertEquals(1, repository.restore(Uri.fromFile(zip)))
        val notebooks = repository.notebooks.first()
        assertEquals(2, notebooks.size)
        val restoredId = notebooks.single { it.id != notebookId }.id
        val restoredPage = repository.observePages(restoredId).first().single()
        assertNotEquals(page.id, restoredPage.id)
        val restored = repository.loadPage(restoredPage.id)
        assertArrayEquals(encoded, restored.strokes.single().inputs)
        assertEquals(box.text, restored.textBoxes.single().text)
        assertEquals(restoredPage.id, restored.strokes.single().pageId)
        InkSupport.validate(restored.strokes.single())
        repository.deleteNotebook(notebookId)
        repository.deleteNotebook(restoredId)
    }

    @Test fun importedPdfRetainsMixedPageSizesAndSurvivesSourceRemoval() = runBlocking {
        val source = temporary("mixed", ".pdf")
        val pdf = PdfDocument()
        try {
            listOf(595 to 842, 842 to 595).forEachIndexed { index, dimensions ->
                val page = pdf.startPage(PdfDocument.PageInfo.Builder(dimensions.first, dimensions.second, index + 1).create())
                page.canvas.drawColor(Color.WHITE)
                page.canvas.drawText("Page ${index + 1}", 40f, 80f, Paint().apply { textSize = 24f })
                pdf.finishPage(page)
            }
            source.outputStream().use(pdf::writeTo)
        } finally { pdf.close() }
        val id = repository.importDocument(Uri.fromFile(source))
        source.delete()
        val pages = repository.observePages(id).first()
        assertEquals(2, pages.size)
        assertEquals(595f, pages[0].width, 0.001f)
        assertEquals(842f, pages[1].width, 0.001f)
        DocumentRenderer(context).renderBackground(pages[1], 600).recycle()
        repository.deleteNotebook(id)
    }

    private fun temporary(prefix: String, suffix: String) = File.createTempFile(prefix, suffix, context.cacheDir).also(temporaryFiles::add)
}
