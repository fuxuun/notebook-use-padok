package com.qingji.notes

import android.content.Context
import android.graphics.BitmapFactory
import kotlinx.coroutines.ensureActive
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import kotlin.coroutines.coroutineContext

internal data class NotebookBundle(val notebook: NotebookEntity, val pages: List<PageContent>)

internal class BackupCodec(private val context: Context) {
    suspend fun write(bundles: List<NotebookBundle>, output: OutputStream) {
        val assets = bundles.flatMap { it.pages }.mapNotNull { it.page.assetPath }.distinct()
        val strokes = bundles.flatMap { it.pages }.flatMap { it.strokes }
        require(assets.size + strokes.size + 1 <= MAX_ENTRIES) { "备份内容过多，请先整理笔记" }
        require(bundles.sumOf { it.pages.size } <= MAX_TOTAL_PAGES) { "备份最多支持 $MAX_TOTAL_PAGES 页" }
        val manifest = JSONObject().put("format", "qingji").put("version", 1)
            .put("notebooks", JSONArray().apply {
                bundles.forEach { bundle ->
                    put(JSONObject().put("id", bundle.notebook.id).put("title", bundle.notebook.title).put("updatedAt", bundle.notebook.updatedAt)
                        .put("pages", JSONArray().apply { bundle.pages.forEach { put(pageJson(it)) } }))
                }
            }).toString().toByteArray(Charsets.UTF_8)
        require(manifest.size <= MAX_MANIFEST_BYTES) { "备份中的笔记信息过多，请先整理笔记" }
        var total = manifest.size.toLong()
        ZipOutputStream(output.buffered()).use { zip ->
            zip.putNextEntry(ZipEntry("manifest.json")); zip.write(manifest); zip.closeEntry()
            val renderer = DocumentRenderer(context)
            assets.forEach { path ->
                coroutineContext.ensureActive()
                require(isAssetPath(path)) { "资料文件路径无效" }
                val file = renderer.assetFile(path)
                require(file.length() <= NoteRepository.MAX_SOURCE_BYTES) { "资料文件过大" }
                zip.putNextEntry(ZipEntry(path))
                file.inputStream().use { total += NoteRepository.copyBounded(it, zip, MAX_EXPANDED_BYTES - total) }
                zip.closeEntry()
            }
            strokes.forEach { stroke ->
                coroutineContext.ensureActive()
                require(stroke.inputs.size <= MAX_INK_BYTES) { "单条笔迹过大" }
                total += stroke.inputs.size
                require(total <= MAX_EXPANDED_BYTES) { "备份超过 512 MiB，请先整理笔记" }
                zip.putNextEntry(ZipEntry("ink/${stroke.id}.bin")); zip.write(stroke.inputs); zip.closeEntry()
            }
        }
    }

    suspend fun read(input: InputStream, staging: File): List<NotebookBundle> {
        val extracted = extract(input, staging)
        require("manifest.json" in extracted) { "备份缺少笔记信息" }
        val manifest = try { JSONObject(File(staging, "manifest.json").readText(Charsets.UTF_8)) }
        catch (error: Exception) { throw IllegalArgumentException("备份信息损坏", error) }
        require(manifest.optString("format") == "qingji" && manifest.optInt("version", -1) == 1) { "不支持此备份格式或版本" }
        val notebookIds = mutableSetOf<String>()
        val pageIds = mutableSetOf<String>()
        val strokeIds = mutableSetOf<String>()
        val boxIds = mutableSetOf<String>()
        val usedFiles = mutableSetOf("manifest.json")
        val notebooks = manifest.getJSONArray("notebooks")
        require(notebooks.length() <= MAX_TOTAL_PAGES) { "备份笔记数量过多" }
        val bundles = (0 until notebooks.length()).map { notebookIndex ->
            coroutineContext.ensureActive()
            val noteJson = notebooks.getJSONObject(notebookIndex)
            val noteId = checkedId(noteJson.getString("id"))
            require(notebookIds.add(noteId)) { "备份包含重复笔记" }
            val title = noteJson.getString("title")
            require(title.isNotBlank() && title.length <= 120) { "笔记名称无效" }
            val notebook = NotebookEntity(noteId, title, noteJson.getLong("updatedAt"))
            val pages = noteJson.getJSONArray("pages")
            require(pages.length() in 1..NoteRepository.MAX_PAGES) { "备份中的笔记页数无效" }
            val pagePositions = mutableSetOf<Int>()
            val contents = (0 until pages.length()).map { index ->
                val json = pages.getJSONObject(index)
                val id = checkedId(json.getString("id"))
                require(pageIds.add(id) && pageIds.size <= MAX_TOTAL_PAGES) { "备份包含重复页面或页面过多" }
                val position = json.getInt("position")
                require(position >= 0 && pagePositions.add(position)) { "页面顺序无效" }
                val asset = nullableString(json, "assetPath")
                if (asset != null) {
                    require(isAssetPath(asset) && asset in extracted) { "备份缺少引用的资料文件" }
                    usedFiles += asset
                }
                val page = PageEntity(id, noteId, position, finiteFloat(json, "width"), finiteFloat(json, "height"), json.getString("background"), asset, json.getInt("sourcePage"), nullableString(json, "text"))
                require(page.width in 1f..20000f && page.height in 1f..20000f && page.sourcePage >= 0) { "页面尺寸或页码无效" }
                require(page.background in setOf("blank", "lined", "grid", "infinite", "pdf", "image", "text")) { "纸张类型不受支持" }
                if (page.background in setOf("pdf", "image")) require(asset != null) { "页面缺少资料文件" }
                if (page.background == "text") require(page.text != null && page.text.length <= NoteRepository.MAX_TEXT_BYTES) { "文本页面内容无效" }
                val strokeArray = json.getJSONArray("strokes")
                require(strokeArray.length() <= MAX_ENTRIES) { "笔迹数量过多" }
                val strokes = (0 until strokeArray.length()).map { strokeIndex ->
                    val value = strokeArray.getJSONObject(strokeIndex)
                    val strokeId = checkedId(value.getString("id"))
                    require(strokeIds.add(strokeId)) { "备份包含重复笔迹" }
                    val path = "ink/$strokeId.bin"
                    require(path in extracted && value.getString("input") == path) { "备份缺少笔迹文件" }
                    usedFiles += path
                    StrokeEntity(strokeId, id, strokeIndex, value.getString("brush"), value.getLong("color"), finiteFloat(value, "size"), File(staging, path).readBytes()).also { InkSupport.validate(it) }
                }
                val boxArray = json.getJSONArray("textBoxes")
                require(boxArray.length() <= 10000) { "文字框数量过多" }
                val boxes = (0 until boxArray.length()).map { boxIndex ->
                    val value = boxArray.getJSONObject(boxIndex)
                    val boxId = checkedId(value.getString("id"))
                    require(boxIds.add(boxId)) { "备份包含重复文字框" }
                    TextBoxEntity(boxId, id, boxIndex, value.getString("text"), finiteFloat(value, "x"), finiteFloat(value, "y"), finiteFloat(value, "width"), finiteFloat(value, "fontSize"), value.getLong("color"))
                }
                PageContent(page, strokes, boxes).also { NoteRepository.validateAnnotations(it) }
            }
            NotebookBundle(notebook, contents.sortedBy { it.page.position })
        }
        require(usedFiles == extracted) { "备份包含未引用的文件" }
        validateAssets(bundles, staging)
        return bundles
    }

    private suspend fun extract(input: InputStream, staging: File): Set<String> {
        val names = mutableSetOf<String>()
        var total = 0L
        ZipInputStream(input.buffered()).use { zip ->
            while (true) {
                coroutineContext.ensureActive()
                val entry = zip.nextEntry ?: break
                val name = entry.name
                require(!entry.isDirectory && (name == "manifest.json" || isAssetPath(name) || INK_PATH.matches(name))) { "备份包含无效文件路径" }
                require(names.add(name) && names.size <= MAX_ENTRIES) { "备份包含重复文件或文件过多" }
                val limit = when {
                    name == "manifest.json" -> MAX_MANIFEST_BYTES.toLong()
                    name.startsWith("ink/") -> MAX_INK_BYTES.toLong()
                    else -> NoteRepository.MAX_SOURCE_BYTES
                }
                val file = File(staging, name)
                file.parentFile?.mkdirs()
                file.outputStream().use { total += NoteRepository.copyBounded(zip, it, minOf(limit, MAX_EXPANDED_BYTES - total)) }
                zip.closeEntry()
            }
        }
        return names
    }

    private suspend fun validateAssets(bundles: List<NotebookBundle>, staging: File) {
        val pages = bundles.flatMap { it.pages }.map { it.page }
        pages.filter { it.background == "pdf" }.groupBy { it.assetPath!! }.forEach { (path, references) ->
            coroutineContext.ensureActive()
            val original = NoteRepository.inspectPdf(File(staging, path), "validation", path)
            references.forEach { page ->
                val matching = original.getOrNull(page.sourcePage)
                require(matching != null && matching.width == page.width && matching.height == page.height) { "PDF 页面与备份信息不一致" }
            }
        }
        pages.filter { it.background == "image" }.map { it.assetPath!! }.distinct().forEach { path ->
            coroutineContext.ensureActive()
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(File(staging, path).path, bounds)
            require(bounds.outWidth > 0 && bounds.outHeight > 0 && bounds.outMimeType in setOf("image/png", "image/jpeg")) { "备份中的图片损坏" }
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 512) sample *= 2
            val bitmap = BitmapFactory.decodeFile(File(staging, path).path, BitmapFactory.Options().apply { inSampleSize = sample })
            requireNotNull(bitmap) { "备份中的图片无法解码" }
            bitmap.recycle()
        }
    }

    private fun pageJson(content: PageContent): JSONObject {
        val page = content.page
        return JSONObject().put("id", page.id).put("position", page.position).put("width", page.width).put("height", page.height)
            .put("background", page.background).put("assetPath", page.assetPath ?: JSONObject.NULL).put("sourcePage", page.sourcePage).put("text", page.text ?: JSONObject.NULL)
            .put("strokes", JSONArray().apply {
                content.strokes.forEach { stroke -> put(JSONObject().put("id", stroke.id).put("brush", stroke.brush).put("color", stroke.color).put("size", stroke.size).put("input", "ink/${stroke.id}.bin")) }
            })
            .put("textBoxes", JSONArray().apply {
                content.textBoxes.forEach { box ->
                    put(JSONObject().put("id", box.id).put("text", box.text).put("x", box.x).put("y", box.y).put("width", box.width).put("fontSize", box.fontSize).put("color", box.color))
                }
            })
    }

    companion object {
        const val MAX_EXPANDED_BYTES = 512L * 1024 * 1024
        private const val MAX_MANIFEST_BYTES = 16 * 1024 * 1024
        private const val MAX_INK_BYTES = 2 * 1024 * 1024
        private const val MAX_ENTRIES = 50000
        private const val MAX_TOTAL_PAGES = 10000
        private val ID = Regex("[A-Za-z0-9_-]{1,128}")
        private val ASSET_PATH = Regex("assets/[A-Za-z0-9_-]{1,128}")
        private val INK_PATH = Regex("ink/[A-Za-z0-9_-]{1,128}\\.bin")

        private fun isAssetPath(path: String) = ASSET_PATH.matches(path)
        private fun checkedId(id: String): String = id.also { require(ID.matches(it)) { "备份标识无效" } }
        private fun nullableString(json: JSONObject, name: String) = if (json.isNull(name)) null else json.getString(name)
        private fun finiteFloat(json: JSONObject, name: String): Float = json.getDouble(name).toFloat().also { require(it.isFinite()) { "备份包含无效数值" } }
    }
}
