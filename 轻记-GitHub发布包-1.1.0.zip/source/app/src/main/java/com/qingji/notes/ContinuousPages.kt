package com.qingji.notes

import android.graphics.Bitmap
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
internal fun ContinuousPages(
    state: NotesUiState,
    vm: NotesViewModel,
    listState: LazyListState,
    onActivated: (NoteCanvasView, PageContent, Bitmap) -> Unit,
    onTextRequested: (TextBoxEntity) -> Unit,
    onHistoryChanged: (NoteCanvasView, Boolean, Boolean) -> Unit,
    onSelectionChanged: (NoteCanvasView, Boolean) -> Unit,
    modifier: Modifier = Modifier,
) {
    LazyColumn(state = listState, modifier = modifier, contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        itemsIndexed(state.pages, key = { _, page -> page.id }) { index, page ->
            var snapshot by remember(page.id) { mutableStateOf<PageContent?>(null) }
            var bitmap by remember(page.id) { mutableStateOf<Bitmap?>(null) }
            var error by remember(page.id) { mutableStateOf<String?>(null) }
            var view by remember(page.id) { mutableStateOf<NoteCanvasView?>(null) }
            LaunchedEffect(page.id, state.pageRevisions[page.id]) {
                try {
                    snapshot = vm.loadVisiblePage(page.id)
                } catch (failure: Exception) {
                    if (failure is CancellationException) throw failure
                    error = failure.localizedMessage ?: "页面无法打开"
                }
            }
            LaunchedEffect(page.id) {
                try {
                    bitmap = withContext(Dispatchers.IO) { vm.renderer.renderBackground(page) }
                } catch (failure: Exception) {
                    if (failure is CancellationException) throw failure
                    error = failure.localizedMessage ?: "页面无法打开"
                }
            }
            val current = if (state.content?.page?.id == page.id) state.content else snapshot
            val latestContent by rememberUpdatedState(current)
            val latestActivate by rememberUpdatedState(onActivated)
            val latestText by rememberUpdatedState(onTextRequested)
            val latestHistory by rememberUpdatedState(onHistoryChanged)
            val latestSelection by rememberUpdatedState(onSelectionChanged)
            fun activate() {
                val canvas = view ?: return
                val content = latestContent ?: return
                val background = bitmap ?: return
                latestActivate(canvas, content, background)
            }
            LaunchedEffect(listState.firstVisibleItemIndex, listState.isScrollInProgress, view, bitmap, state.busy) {
                if (state.busy == null && !listState.isScrollInProgress && listState.firstVisibleItemIndex == index) activate()
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("第 ${index + 1} 页", fontSize = 11.sp, modifier = Modifier.padding(bottom = 4.dp))
                Box(Modifier.fillMaxWidth().aspectRatio(page.width / page.height).background(Color.White), contentAlignment = Alignment.Center) {
                    if (current != null && bitmap != null) {
                        AndroidView(
                            factory = { context ->
                                NoteCanvasView(context).also { canvas ->
                                    view = canvas
                                    canvas.scrollingDocument = true
                                    canvas.onActivated = { activate() }
                                    canvas.onContentChanged = { updated -> snapshot = updated; vm.edit(updated) }
                                    canvas.onTextRequested = { latestText(it) }
                                    canvas.onHistoryChanged = { undo, redo -> latestHistory(canvas, undo, redo) }
                                    canvas.onSelectionChanged = { latestSelection(canvas, it) }
                                }
                            },
                            update = { canvas ->
                                canvas.isEnabled = state.busy == null
                                canvas.setSettings(state.settings)
                                canvas.setPage(current, bitmap)
                            },
                            modifier = Modifier.fillMaxSize(),
                        )
                    } else if (error != null) Text(error!!, modifier = Modifier.padding(16.dp))
                    else CircularProgressIndicator(Modifier.size(24.dp))
                }
            }
        }
    }
}
