package com.qingji.notes

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.exifinterface.media.ExifInterface
import java.io.File
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class DocumentRenderer(private val context: Context) {
    fun contentBounds(content: PageContent): RectF {
        val page = content.page
        if (page.background != "infinite") return RectF(0f, 0f, page.width, page.height)
        var bounds: RectF? = null
        fun include(rect: RectF) {
            if (bounds == null) bounds = RectF(rect) else bounds!!.union(rect)
        }
        content.strokes.forEach { entity ->
            InkSupport.decode(entity).shape.computeBoundingBox()?.let { include(RectF(it.xMin, it.yMin, it.xMax, it.yMax)) }
        }
        content.textBoxes.forEach { box ->
            val height = textLayout(box.text.ifEmpty { " " }, box.width, box.fontSize, box.color.toInt()).height.toFloat()
            include(RectF(box.x, box.y, box.x + box.width, box.y + max(height, box.fontSize)))
        }
        return bounds?.apply { inset(-MARGIN, -MARGIN) } ?: RectF(0f, 0f, page.width, page.height)
    }

    /** Flatten the same world region for thumbnails and exports, including negative draft coordinates. */
    fun renderContent(content: PageContent, maxDimension: Int = 1800, bounds: RectF = contentBounds(content)): Bitmap {
        val infinite = content.page.background == "infinite"
        val scale = min(maxDimension.coerceIn(64, 2500).toFloat() / max(bounds.width(), bounds.height()), 3f)
        val bitmap = if (infinite) Bitmap.createBitmap(
            max(1, (bounds.width() * scale).roundToInt()), max(1, (bounds.height() * scale).roundToInt()), Bitmap.Config.ARGB_8888,
        ) else renderBackground(content.page, maxDimension)
        try {
            val canvas = Canvas(bitmap)
            canvas.scale(bitmap.width / bounds.width(), bitmap.height / bounds.height())
            canvas.translate(-bounds.left, -bounds.top)
            canvas.clipRect(bounds)
            if (infinite) InfiniteCanvas.drawGrid(canvas, bounds, scale)
            InkSupport.drawStrokes(canvas, content.strokes)
            content.textBoxes.forEach { drawTextBox(canvas, it) }
            return bitmap
        } catch (error: Throwable) {
            bitmap.recycle()
            throw error
        }
    }

    fun assetFile(path: String): File {
        val root = File(context.filesDir, "assets").canonicalFile
        val file = File(context.filesDir, path).canonicalFile
        require(file.path.startsWith(root.path + File.separator)) { "资料文件路径无效" }
        require(file.isFile) { "资料文件不存在，请从备份恢复" }
        return file
    }

    fun renderBackground(page: PageEntity, maxDimension: Int = 1800): Bitmap {
        require(page.width.isFinite() && page.height.isFinite() && page.width > 0 && page.height > 0)
        val scale = min(maxDimension.coerceIn(64, 2500).toFloat() / max(page.width, page.height), 3f)
        val bitmap = Bitmap.createBitmap(max(1, (page.width * scale).roundToInt()), max(1, (page.height * scale).roundToInt()), Bitmap.Config.ARGB_8888)
        try {
            val canvas = Canvas(bitmap)
            canvas.drawColor(Color.WHITE)
            if (page.background == "pdf") {
                ParcelFileDescriptor.open(assetFile(requireNotNull(page.assetPath)), ParcelFileDescriptor.MODE_READ_ONLY).use { descriptor ->
                    PdfRenderer(descriptor).use { renderer ->
                        require(page.sourcePage in 0 until renderer.pageCount) { "PDF 页码无效" }
                        renderer.openPage(page.sourcePage).use { pdfPage ->
                            pdfPage.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        }
                    }
                }
                return bitmap
            }
            canvas.scale(bitmap.width / page.width, bitmap.height / page.height)
            when (page.background) {
                "lined", "grid" -> drawRuling(canvas, page)
                "image" -> drawImage(canvas, page, scale)
                "text" -> {
                    canvas.save()
                    canvas.translate(MARGIN, MARGIN)
                    textLayout(page.text.orEmpty(), page.width - 2 * MARGIN, TEXT_SIZE, 0xFF25332F.toInt(), 1.35f).draw(canvas)
                    canvas.restore()
                }
            }
            return bitmap
        } catch (error: Throwable) {
            bitmap.recycle()
            throw error
        }
    }

    private fun drawRuling(canvas: Canvas, page: PageEntity) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFDCE5E0.toInt(); strokeWidth = 0.6f }
        var y = 32f
        while (y < page.height) {
            canvas.drawLine(0f, y, page.width, y, paint)
            y += if (page.background == "grid") 20f else 28f
        }
        if (page.background == "grid") {
            var x = 20f
            while (x < page.width) { canvas.drawLine(x, 0f, x, page.height, paint); x += 20f }
        }
    }

    private fun drawImage(canvas: Canvas, page: PageEntity, scale: Float) {
        val file = assetFile(requireNotNull(page.assetPath))
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.path, bounds)
        require(bounds.outWidth > 0 && bounds.outHeight > 0) { "图片无法读取" }
        val target = ceil(max(page.width, page.height) * scale).toInt()
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > target * 2) sample *= 2
        val source = BitmapFactory.decodeFile(file.path, BitmapFactory.Options().apply { inSampleSize = sample })
            ?: throw IllegalArgumentException("图片无法读取")
        var oriented = source
        try {
            val exif = ExifInterface(file)
            val matrix = Matrix()
            if (exif.isFlipped) matrix.postScale(-1f, 1f)
            if (exif.rotationDegrees != 0) matrix.postRotate(exif.rotationDegrees.toFloat())
            if (!matrix.isIdentity) oriented = Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
            val ratio = min(page.width / oriented.width, page.height / oriented.height)
            val w = oriented.width * ratio
            val h = oriented.height * ratio
            canvas.drawBitmap(oriented, null, RectF((page.width - w) / 2, (page.height - h) / 2, (page.width + w) / 2, (page.height + h) / 2), Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
        } finally {
            if (oriented !== source) oriented.recycle()
            source.recycle()
        }
    }

    fun drawTextBox(canvas: Canvas, box: TextBoxEntity) {
        canvas.save()
        canvas.translate(box.x, box.y)
        textLayout(box.text, box.width, box.fontSize, box.color.toInt()).draw(canvas)
        canvas.restore()
    }

    companion object {
        const val MARGIN = 36f
        const val TEXT_SIZE = 14f

        fun textLayout(text: String, width: Float, size: Float, color: Int, spacing: Float = 1.2f): StaticLayout {
            val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = size; this.color = color }
            return StaticLayout.Builder.obtain(text, 0, text.length, paint, max(1, width.toInt()))
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setIncludePad(false)
                .setLineSpacing(0f, spacing)
                .build()
        }

        fun paginateText(text: String, width: Float = 595f, height: Float = 842f): List<String> {
            if (text.isEmpty()) return listOf("")
            val layout = textLayout(text, width - 2 * MARGIN, TEXT_SIZE, Color.BLACK, 1.35f)
            val result = mutableListOf<String>()
            var firstLine = 0
            while (firstLine < layout.lineCount) {
                var endLine = firstLine
                val top = layout.getLineTop(firstLine)
                while (endLine + 1 < layout.lineCount && layout.getLineBottom(endLine + 1) - top <= height - 2 * MARGIN) endLine++
                result += text.substring(layout.getLineStart(firstLine), layout.getLineEnd(endLine))
                firstLine = endLine + 1
            }
            return result
        }
    }
}
