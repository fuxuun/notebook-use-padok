package com.qingji.notes

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import kotlin.math.abs
import kotlin.math.floor

internal object InfiniteCanvas {
    // Keep world coordinates within reliable float precision; no backing bitmap grows with them.
    const val COORDINATE_LIMIT = 1_000_000f
    fun validCoordinate(value: Float) = value.isFinite() && abs(value) <= COORDINATE_LIMIT

    fun drawGrid(canvas: Canvas, visible: RectF, scale: Float) {
        canvas.drawColor(Color.WHITE)
        var step = 20f
        while (step * scale < 16f) step *= 2f
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFE3EAE5.toInt(); strokeWidth = 0.7f / scale }
        var x = floor(visible.left / step) * step
        while (x <= visible.right) { canvas.drawLine(x, visible.top, x, visible.bottom, paint); x += step }
        var y = floor(visible.top / step) * step
        while (y <= visible.bottom) { canvas.drawLine(visible.left, y, visible.right, y, paint); y += step }
    }
}
