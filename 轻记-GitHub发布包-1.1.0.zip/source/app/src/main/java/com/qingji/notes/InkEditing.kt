package com.qingji.notes

import android.graphics.PointF
import android.graphics.RectF
import androidx.ink.brush.InputToolType
import androidx.ink.strokes.MutableStrokeInputBatch
import androidx.ink.strokes.Stroke
import androidx.ink.strokes.StrokeInput
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

internal object InkEditing {
    fun bounds(stroke: Stroke): RectF {
        val bounds = stroke.shape.computeBoundingBox()
        if (bounds != null) return RectF(bounds.xMin, bounds.yMin, bounds.xMax, bounds.yMax).apply { inset(-0.05f, -0.05f) }
        val first = stroke.inputs[0]
        return RectF(first.x - 0.05f, first.y - 0.05f, first.x + 0.05f, first.y + 0.05f)
    }

    fun selected(stroke: Stroke, polygon: List<PointF>): Boolean {
        if (polygon.size < 3 || stroke.inputs.isEmpty()) return false
        val area = RectF(polygon.minOf { it.x }, polygon.minOf { it.y }, polygon.maxOf { it.x }, polygon.maxOf { it.y })
        if (!RectF.intersects(area, bounds(stroke))) return false
        val input = StrokeInput()
        var previous: PointF? = null
        for (i in 0 until stroke.inputs.size) {
            stroke.inputs.populate(i, input)
            val point = PointF(input.x, input.y)
            if (inside(point, polygon)) return true
            val start = previous
            if (start != null && polygon.indices.any { intersects(start, point, polygon[it], polygon[(it + 1) % polygon.size]) }) return true
            previous = point
        }
        return false
    }

    private fun inside(point: PointF, polygon: List<PointF>): Boolean {
        var result = false
        var previous = polygon.last()
        for (next in polygon) {
            if ((next.y > point.y) != (previous.y > point.y) &&
                point.x < (previous.x - next.x) * (point.y - next.y) / (previous.y - next.y) + next.x) result = !result
            previous = next
        }
        return result
    }

    private fun intersects(a: PointF, b: PointF, c: PointF, d: PointF): Boolean {
        fun cross(p: PointF, q: PointF, r: PointF) =
            (q.x.toDouble() - p.x) * (r.y.toDouble() - p.y) - (q.y.toDouble() - p.y) * (r.x.toDouble() - p.x)
        if (max(a.x, b.x) < min(c.x, d.x) || max(c.x, d.x) < min(a.x, b.x) ||
            max(a.y, b.y) < min(c.y, d.y) || max(c.y, d.y) < min(a.y, b.y)) return false
        return cross(a, b, c) * cross(a, b, d) <= 0 && cross(c, d, a) * cross(c, d, b) <= 0
    }

    fun transform(entity: StrokeEntity, stroke: Stroke, dx: Float = 0f, dy: Float = 0f,
                  factor: Float = 1f, centerX: Float = 0f, centerY: Float = 0f): StrokeEntity {
        require(factor.isFinite() && factor > 0)
        val output = MutableStrokeInputBatch()
        val input = StrokeInput()
        for (i in 0 until stroke.inputs.size) {
            stroke.inputs.populate(i, input)
            val x = centerX + (input.x - centerX) * factor + dx
            val y = centerY + (input.y - centerY) * factor + dy
            require(InfiniteCanvas.validCoordinate(x) && InfiniteCanvas.validCoordinate(y)) { "已到草稿坐标范围边缘" }
            output.add(input.toolType, x, y, input.elapsedTimeMillis,
                if (input.strokeUnitLengthCm == StrokeInput.NO_STROKE_UNIT_LENGTH) input.strokeUnitLengthCm else input.strokeUnitLengthCm / factor,
                input.pressure, input.tiltRadians, input.orientationRadians)
        }
        return entity.copy(size = (entity.size * factor).coerceIn(0.1f, 128f), inputs = InkSupport.encode(output))
    }

    fun shape(page: PageEntity, tool: EditorTool, start: PointF, end: PointF, settings: EditorSettings, position: Int): StrokeEntity? {
        if (hypot(end.x - start.x, end.y - start.y) < 0.5f) return null
        val points = mutableListOf<PointF>()
        fun edge(a: PointF, b: PointF) {
            val count = ceil(hypot(b.x - a.x, b.y - a.y) / max(settings.penSize, 2f)).toInt().coerceIn(1, 512)
            for (i in 0 until count) points += PointF(a.x + (b.x - a.x) * i / count, a.y + (b.y - a.y) * i / count)
        }
        when (tool) {
            EditorTool.LINE -> { edge(start, end); points += end }
            EditorTool.RECTANGLE -> {
                val second = PointF(end.x, start.y)
                val fourth = PointF(start.x, end.y)
                edge(start, second); edge(second, end); edge(end, fourth); edge(fourth, start); points += start
            }
            EditorTool.ELLIPSE -> {
                val cx = (start.x + end.x) / 2; val cy = (start.y + end.y) / 2
                val rx = abs(end.x - start.x) / 2; val ry = abs(end.y - start.y) / 2
                val count = ceil(2 * PI * max(rx, ry) / max(settings.penSize, 2f)).toInt().coerceIn(48, 512)
                for (i in 0..count) {
                    val angle = 2 * PI * i / count
                    points += PointF(cx + rx * cos(angle).toFloat(), cy + ry * sin(angle).toFloat())
                }
            }
            else -> return null
        }
        val batch = MutableStrokeInputBatch()
        points.forEachIndexed { index, point -> batch.add(InputToolType.STYLUS, point.x, point.y, index * 8L, pressure = 0.5f) }
        return StrokeEntity(pageId = page.id, position = position, brush = InkSupport.PEN,
            color = settings.color or 0xFF000000L, size = settings.penSize, inputs = InkSupport.encode(batch))
    }
}
