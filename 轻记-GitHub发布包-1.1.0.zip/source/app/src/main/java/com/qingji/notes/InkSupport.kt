package com.qingji.notes

import android.graphics.Canvas
import android.graphics.Matrix
import androidx.ink.brush.Brush
import androidx.ink.brush.SelfOverlap
import androidx.ink.brush.StockBrushes
import androidx.ink.rendering.android.canvas.CanvasStrokeRenderer
import androidx.ink.storage.decode
import androidx.ink.storage.encode
import androidx.ink.strokes.Stroke
import androidx.ink.strokes.StrokeInputBatch
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.GZIPInputStream

object InkSupport {
    const val PEN = "pressure-v1"
    const val HIGHLIGHTER = "highlighter-v1"

    fun brush(kind: String, color: Long, size: Float): Brush {
        require(size.isFinite() && size in 0.1f..128f) { "笔刷粗细无效" }
        require(color in 0..0xFFFFFFFFL) { "笔刷颜色无效" }
        val family = when (kind) {
            PEN -> StockBrushes.pressurePen(StockBrushes.PressurePenVersion.V1)
            HIGHLIGHTER -> StockBrushes.highlighter(
                selfOverlap = SelfOverlap.DISCARD,
                version = StockBrushes.HighlighterVersion.V1,
            )
            else -> throw IllegalArgumentException("不支持的笔刷版本")
        }
        return Brush.createWithColorIntArgb(family, color.toInt(), size, 0.1f)
    }

    fun encode(inputs: StrokeInputBatch): ByteArray = ByteArrayOutputStream().also { inputs.encode(it) }.toByteArray()

    fun decode(entity: StrokeEntity): Stroke = Stroke(
        brush(entity.brush, entity.color, entity.size),
        StrokeInputBatch.decode(ByteArrayInputStream(entity.inputs)),
    )

    fun validate(entity: StrokeEntity) {
        require(entity.inputs.size in 1..(2 * 1024 * 1024)) { "笔迹数据过大或为空" }
        // Ink batches contain their own gzip stream, independent of the outer backup ZIP.
        GZIPInputStream(ByteArrayInputStream(entity.inputs)).use { input ->
            val buffer = ByteArray(8192)
            var total = 0
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                total += count
                require(total <= 8 * 1024 * 1024) { "笔迹解压后过大" }
            }
        }
        val inputs = StrokeInputBatch.decode(ByteArrayInputStream(entity.inputs))
        require(inputs.size in 1..200_000) { "笔迹点数无效" }
        for (i in 0 until inputs.size) {
            val point = inputs[i]
            require(InfiniteCanvas.validCoordinate(point.x) && InfiniteCanvas.validCoordinate(point.y)) { "笔迹坐标无效" }
        }
        brush(entity.brush, entity.color, entity.size)
    }

    @Suppress("DEPRECATION")
    fun drawStrokes(canvas: Canvas, strokes: List<StrokeEntity>) {
        if (strokes.isEmpty()) return
        // Each call owns its renderer, so thumbnail and PDF workers do not share mutable caches.
        val renderer = CanvasStrokeRenderer.create()
        val transform = Matrix().also(canvas::getMatrix)
        for (entity in strokes) renderer.draw(canvas, decode(entity), transform)
    }
}
