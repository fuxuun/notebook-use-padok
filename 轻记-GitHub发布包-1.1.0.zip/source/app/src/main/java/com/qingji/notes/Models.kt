package com.qingji.notes

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import java.util.UUID

fun newId(): String = UUID.randomUUID().toString()

@Entity(tableName = "notebooks")
data class NotebookEntity(
    @PrimaryKey val id: String = newId(),
    val title: String,
    val updatedAt: Long = System.currentTimeMillis(),
)

@Entity(
    tableName = "pages",
    foreignKeys = [ForeignKey(entity = NotebookEntity::class, parentColumns = ["id"], childColumns = ["notebookId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("notebookId")],
)
data class PageEntity(
    @PrimaryKey val id: String = newId(),
    val notebookId: String,
    val position: Int,
    val width: Float = 595f,
    val height: Float = 842f,
    // blank, lined, grid, pdf, image or text; dimensions and annotations use page points.
    val background: String = "blank",
    val assetPath: String? = null,
    val sourcePage: Int = 0,
    val text: String? = null,
)

@Entity(
    tableName = "strokes",
    foreignKeys = [ForeignKey(entity = PageEntity::class, parentColumns = ["id"], childColumns = ["pageId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("pageId")],
)
data class StrokeEntity(
    @PrimaryKey val id: String = newId(),
    val pageId: String,
    val position: Int,
    val brush: String,
    val color: Long,
    val size: Float,
    val inputs: ByteArray,
)

@Entity(
    tableName = "text_boxes",
    foreignKeys = [ForeignKey(entity = PageEntity::class, parentColumns = ["id"], childColumns = ["pageId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("pageId")],
)
data class TextBoxEntity(
    @PrimaryKey val id: String = newId(),
    val pageId: String,
    val position: Int,
    val text: String,
    val x: Float,
    val y: Float,
    val width: Float = 220f,
    val fontSize: Float = 18f,
    val color: Long = 0xFF25332FL,
)

data class PageContent(
    val page: PageEntity,
    val strokes: List<StrokeEntity> = emptyList(),
    val textBoxes: List<TextBoxEntity> = emptyList(),
)

enum class EditorTool { PEN, HIGHLIGHTER, ERASER, TEXT, HAND, LASSO, LINE, RECTANGLE, ELLIPSE }

data class EditorSettings(
    val tool: EditorTool = EditorTool.PEN,
    val color: Long = 0xFF25332FL,
    val penSize: Float = 2.5f,
    val highlighterSize: Float = 16f,
    val fingerWriting: Boolean = false,
)
