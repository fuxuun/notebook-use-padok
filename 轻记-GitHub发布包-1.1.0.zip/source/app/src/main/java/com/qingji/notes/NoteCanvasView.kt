package com.qingji.notes

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import androidx.ink.brush.InputToolType
import androidx.ink.geometry.AffineTransform
import androidx.ink.geometry.ImmutableParallelogram
import androidx.ink.geometry.ImmutableSegment
import androidx.ink.geometry.ImmutableVec
import androidx.ink.geometry.Intersection.intersects
import androidx.ink.rendering.android.canvas.CanvasStrokeRenderer
import androidx.ink.strokes.ImmutableStrokeInputBatch
import androidx.ink.strokes.InProgressStroke
import androidx.ink.strokes.MutableStrokeInputBatch
import androidx.ink.strokes.Stroke
import androidx.ink.strokes.StrokeInput
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/** Page-space transform shared by drawing and input; changing zoom never changes stored content. */
internal class PageViewport {
    var scale = 1f; private set
    var x = 0f; private set
    var y = 0f; private set
    private var fitScale = 1f
    var infinite = false

    fun fit(viewWidth: Float, viewHeight: Float, pageWidth: Float, pageHeight: Float, margin: Float) {
        if (viewWidth <= 0f || viewHeight <= 0f) return
        fitScale = min((viewWidth - 2 * margin) / pageWidth, (viewHeight - 2 * margin) / pageHeight).coerceAtLeast(0.01f)
        scale = fitScale
        x = (viewWidth - pageWidth * scale) / 2f
        y = (viewHeight - pageHeight * scale) / 2f
    }

    fun pageX(screenX: Float): Float = (screenX - x) / scale
    fun pageY(screenY: Float): Float = (screenY - y) / scale

    fun move(dx: Float, dy: Float) { x += dx; y += dy }

    fun zoom(factor: Float, focusX: Float, focusY: Float) {
        if (!factor.isFinite() || factor <= 0f) return
        val px = pageX(focusX)
        val py = pageY(focusY)
        scale = if (infinite) (scale * factor).coerceIn(0.0001f, 32f)
        else (scale * factor).coerceIn(fitScale * 0.75f, fitScale * 8f)
        x = focusX - px * scale
        y = focusY - py * scale
    }
}

internal class PageHistory {
    private val past = ArrayDeque<PageContent>()
    private val future = ArrayDeque<PageContent>()
    val canUndo get() = past.isNotEmpty()
    val canRedo get() = future.isNotEmpty()
    fun clear() { past.clear(); future.clear() }
    fun retainedStrokeIds(): Set<String> = (past.asSequence() + future.asSequence())
        .flatMap { it.strokes.asSequence() }.map { it.id }.toSet()
    fun record(before: PageContent) {
        past.addLast(before)
        // ponytail: keep 100 shared snapshots per open page; disk history is outside v1 scope.
        if (past.size > 100) past.removeFirst()
        future.clear()
    }
    fun undo(current: PageContent): PageContent? {
        if (past.isEmpty()) return null
        future.addLast(current)
        return past.removeLast()
    }
    fun redo(current: PageContent): PageContent? {
        if (future.isEmpty()) return null
        past.addLast(current)
        return future.removeLast()
    }
}

class NoteCanvasView(context: Context) : View(context) {
    var onContentChanged: ((PageContent) -> Unit)? = null
    var onTextRequested: ((TextBoxEntity) -> Unit)? = null
    var onHistoryChanged: ((Boolean, Boolean) -> Unit)? = null
    var onSelectionChanged: ((Boolean) -> Unit)? = null
    var onActivated: (() -> Unit)? = null
    var scrollingDocument = false
    val canUndo get() = history.canUndo
    val canRedo get() = history.canRedo
    val hasSelection get() = selectedStrokes.isNotEmpty()

    private var content: PageContent? = null
    val displayedPageId: String? get() = content?.page?.id
    private var lastExternal: PageContent? = null
    private var backgroundBitmap: Bitmap? = null
    private var settings = EditorSettings()
    private val viewport = PageViewport()
    private val history = PageHistory()
    private val documentRenderer = DocumentRenderer(context)
    private val strokeRenderer by lazy { CanvasStrokeRenderer.create() }
    private val decoded = mutableMapOf<String, Pair<StrokeEntity, Stroke>>()
    private val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val selectionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF377D61.toInt(); style = Paint.Style.STROKE }
    private val transform = Matrix()
    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop
    private var selectedText: String? = null
    private val selectedStrokes = mutableSetOf<String>()
    private val lasso = mutableListOf<PointF>()
    private var selectionDx = 0f
    private var selectionDy = 0f
    private var shapeEnd: PointF? = null
    private val previewPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }

    private enum class Gesture { NONE, INK, ERASE, TEXT, PAN, PINCH, LASSO, SELECTION, SHAPE }
    private var gesture = Gesture.NONE
    private var gestureBefore: PageContent? = null
    private var activePointer = -1
    private var activeStylus = false
    private var downX = 0f
    private var downY = 0f
    private var previousX = 0f
    private var previousY = 0f
    private var previousSpan = 0f
    private var moved = false
    private var resizeText = false
    private var textAtDown: TextBoxEntity? = null
    private var progress: InProgressStroke? = null
    private val pendingInputs by lazy { MutableStrokeInputBatch() }
    private var strokeStart = 0L
    private var lastInputTime = -1L
    private var lastInputX = Float.NaN
    private var lastInputY = Float.NaN
    private var activeBrush = InkSupport.PEN
    private var activeColor = 0L
    private var activeSize = 2.5f
    private var erasePoint: PointF? = null

    init {
        isFocusable = true
        contentDescription = "笔记页面，使用触控笔书写，双指缩放或移动；文字工具可编辑文字框"
        setBackgroundColor(0xFFE9EDE8.toInt())
    }

    fun setPage(value: PageContent, bitmap: Bitmap?) {
        val changedPage = content?.page?.id != value.page.id
        if (changedPage) {
            cancelGesture()
            content = value
            backgroundBitmap = bitmap
            history.clear()
            decoded.clear()
            selectedText = null
            clearSelection()
            fitPage()
            reportHistory()
        } else {
            // Saving and recomposition must not replace a gesture with its pre-gesture snapshot.
            if (gestureBefore == null && progress == null && value !== lastExternal) content = value
            if (bitmap != null) backgroundBitmap = bitmap
        }
        lastExternal = value
        invalidate()
    }

    fun setSettings(value: EditorSettings) {
        if (value == settings) return
        if (gesture != Gesture.NONE) cancelGesture()
        settings = value
        if (value.tool != EditorTool.TEXT) selectedText = null
        if (value.tool != EditorTool.LASSO) clearSelection()
        invalidate()
    }

    fun fitPage() {
        val current = content ?: return
        viewport.infinite = current.page.background == "infinite"
        val bounds = documentRenderer.contentBounds(current)
        viewport.fit(width.toFloat(), height.toFloat(), bounds.width(), bounds.height(), 20f * resources.displayMetrics.density)
        if (viewport.infinite) {
            viewport.zoom(min(1f, min(width / bounds.width(), height / bounds.height()) / viewport.scale), width / 2f, height / 2f)
            viewport.move(-bounds.left * viewport.scale, -bounds.top * viewport.scale)
        }
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) { fitPage() }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val current = content ?: return
        canvas.save()
        canvas.translate(viewport.x, viewport.y)
        canvas.scale(viewport.scale, viewport.scale)
        val page = current.page
        if (page.background == "infinite") {
            val visible = RectF(viewport.pageX(0f), viewport.pageY(0f), viewport.pageX(width.toFloat()), viewport.pageY(height.toFloat()))
            InfiniteCanvas.drawGrid(canvas, visible, viewport.scale)
        } else {
            val bounds = RectF(0f, 0f, page.width, page.height)
            bitmapPaint.color = Color.WHITE
            canvas.drawRect(bounds, bitmapPaint)
            backgroundBitmap?.takeUnless { it.isRecycled }?.let { canvas.drawBitmap(it, null, bounds, bitmapPaint) }
            canvas.clipRect(bounds)
        }
        transform.setScale(viewport.scale, viewport.scale)
        for (entity in current.strokes) {
            canvas.save()
            if (entity.id in selectedStrokes) canvas.translate(selectionDx, selectionDy)
            strokeRenderer.draw(canvas, cachedStroke(entity), transform)
            canvas.restore()
        }
        progress?.let { strokeRenderer.draw(canvas, it, transform) }
        for (box in current.textBoxes) documentRenderer.drawTextBox(canvas, box)
        current.textBoxes.find { it.id == selectedText }?.let { box ->
            val rect = textBounds(box)
            selectionPaint.strokeWidth = 1.5f / viewport.scale
            canvas.drawRect(rect, selectionPaint)
            selectionPaint.style = Paint.Style.FILL
            canvas.drawCircle(rect.right, rect.bottom, 6f / viewport.scale, selectionPaint)
            selectionPaint.style = Paint.Style.STROKE
        }
        erasePoint?.takeIf { gesture == Gesture.ERASE }?.let {
            selectionPaint.strokeWidth = 1f / viewport.scale
            canvas.drawCircle(it.x, it.y, eraserRadius(), selectionPaint)
        }
        selectionBounds()?.let { bounds ->
            bounds.offset(selectionDx, selectionDy)
            selectionPaint.strokeWidth = 1.5f / viewport.scale
            bounds.inset(-4f / viewport.scale, -4f / viewport.scale)
            canvas.drawRect(bounds, selectionPaint)
        }
        if (lasso.size > 1) {
            val path = Path().apply {
                moveTo(lasso.first().x, lasso.first().y)
                lasso.drop(1).forEach { lineTo(it.x, it.y) }
                close()
            }
            selectionPaint.strokeWidth = 1.5f / viewport.scale
            canvas.drawPath(path, selectionPaint)
        }
        shapeEnd?.let { end ->
            val start = pagePoint(downX, downY)
            previewPaint.color = (settings.color or 0xFF000000L).toInt()
            previewPaint.strokeWidth = settings.penSize
            val rect = RectF(min(start.x, end.x), min(start.y, end.y), max(start.x, end.x), max(start.y, end.y))
            when (settings.tool) {
                EditorTool.LINE -> canvas.drawLine(start.x, start.y, end.x, end.y, previewPaint)
                EditorTool.RECTANGLE -> canvas.drawRect(rect, previewPaint)
                EditorTool.ELLIPSE -> canvas.drawOval(rect, previewPaint)
                else -> Unit
            }
        }
        canvas.restore()
    }

    private fun cachedStroke(entity: StrokeEntity): Stroke {
        val existing = decoded[entity.id]
        if (existing?.first === entity) return existing.second
        return InkSupport.decode(entity).also { decoded[entity.id] = entity to it }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!isEnabled || content == null) { cancelGesture(); return false }
        if (event.actionMasked == MotionEvent.ACTION_DOWN) onActivated?.invoke()
        if (event.actionMasked == MotionEvent.ACTION_CANCEL) { cancelGesture(); return true }
        if (scrollingDocument && !activeStylus && event.pointerCount == 1 &&
            !isStylus(event, 0) && event.getToolType(0) == MotionEvent.TOOL_TYPE_FINGER &&
            !settings.fingerWriting && settings.tool != EditorTool.TEXT && gesture != Gesture.PINCH) {
            parent?.requestDisallowInterceptTouchEvent(false)
            if (event.actionMasked == MotionEvent.ACTION_DOWN) cancelGesture()
            return true
        }
        parent?.requestDisallowInterceptTouchEvent(true)

        val stylus = (0 until event.pointerCount).firstOrNull { isStylus(event, it) }
        if (event.actionMasked == MotionEvent.ACTION_DOWN ||
            (event.actionMasked == MotionEvent.ACTION_POINTER_DOWN && stylus == event.actionIndex && !activeStylus)) {
            cancelGesture()
            startGesture(event, stylus ?: event.actionIndex)
            return true
        }

        if (activeStylus) {
            val index = event.findPointerIndex(activePointer)
            if (index < 0) { cancelGesture(); return true }
            val isActiveUp = (event.actionMasked == MotionEvent.ACTION_UP || event.actionMasked == MotionEvent.ACTION_POINTER_UP) && event.getPointerId(event.actionIndex) == activePointer
            if (event.actionMasked == MotionEvent.ACTION_MOVE || isActiveUp) updateGesture(event, index)
            if (isActiveUp) {
                if (event.flags and MotionEvent.FLAG_CANCELED != 0) cancelGesture() else finishGesture()
            }
            return true // Ignore palm pointers while a pen is down.
        }

        if (event.pointerCount >= 2 && event.actionMasked != MotionEvent.ACTION_POINTER_UP) {
            val focusX = (event.getX(0) + event.getX(1)) / 2f
            val focusY = (event.getY(0) + event.getY(1)) / 2f
            val span = hypot(event.getX(1) - event.getX(0), event.getY(1) - event.getY(0))
            if (gesture != Gesture.PINCH) {
                cancelGesture()
                gesture = Gesture.PINCH
            } else if (event.actionMasked == MotionEvent.ACTION_MOVE && previousSpan > 1f) {
                viewport.zoom(span / previousSpan, previousX, previousY)
                viewport.move(focusX - previousX, focusY - previousY)
                invalidate()
            }
            previousX = focusX; previousY = focusY; previousSpan = span
            return true
        }
        if (event.actionMasked == MotionEvent.ACTION_POINTER_UP) {
            // End a pinch without turning the remaining finger into a pen.
            if (gesture == Gesture.PINCH) { gesture = Gesture.NONE; activePointer = -1 }
            return true
        }
        val index = event.findPointerIndex(activePointer)
        if (index >= 0 && event.actionMasked == MotionEvent.ACTION_MOVE) updateGesture(event, index)
        if (event.actionMasked == MotionEvent.ACTION_UP) {
            if (index >= 0) updateGesture(event, index)
            if (event.flags and MotionEvent.FLAG_CANCELED != 0) cancelGesture() else finishGesture()
            performClick()
        }
        return true
    }

    override fun performClick(): Boolean { super.performClick(); return true }

    private fun isStylus(event: MotionEvent, index: Int) = event.getToolType(index) == MotionEvent.TOOL_TYPE_STYLUS || event.getToolType(index) == MotionEvent.TOOL_TYPE_ERASER

    private fun startGesture(event: MotionEvent, index: Int) {
        val current = content ?: return
        activePointer = event.getPointerId(index)
        activeStylus = isStylus(event, index)
        downX = event.getX(index); downY = event.getY(index)
        previousX = downX; previousY = downY
        moved = false
        val point = pagePoint(downX, downY)
        val canWrite = activeStylus || settings.fingerWriting || event.getToolType(index) == MotionEvent.TOOL_TYPE_MOUSE
        val tool = if (event.getToolType(index) == MotionEvent.TOOL_TYPE_ERASER) EditorTool.ERASER else settings.tool
        if (tool == EditorTool.HAND || (!canWrite && tool != EditorTool.TEXT) || !onPage(point)) {
            gesture = Gesture.PAN
            return
        }
        gestureBefore = current
        when (tool) {
            EditorTool.PEN, EditorTool.HIGHLIGHTER -> {
                gesture = Gesture.INK
                activeBrush = if (tool == EditorTool.PEN) InkSupport.PEN else InkSupport.HIGHLIGHTER
                activeColor = if (tool == EditorTool.PEN) settings.color or 0xFF000000L else (settings.color and 0xFFFFFFL) or 0x55000000L
                activeSize = if (tool == EditorTool.PEN) settings.penSize else settings.highlighterSize
                progress = InProgressStroke().apply { start(InkSupport.brush(activeBrush, activeColor, activeSize)) }
                strokeStart = event.eventTime
                lastInputTime = -1L; lastInputX = Float.NaN; lastInputY = Float.NaN
                addInputs(event, index)
            }
            EditorTool.ERASER -> {
                gesture = Gesture.ERASE
                erasePoint = point
                erase(point)
            }
            EditorTool.TEXT -> {
                gesture = Gesture.TEXT
                val selected = current.textBoxes.find { it.id == selectedText }
                val handle = selected?.let { textBounds(it) }
                resizeText = handle != null && hypot(point.x - handle.right, point.y - handle.bottom) < 20f / viewport.scale
                textAtDown = if (resizeText) selected else current.textBoxes.asReversed().firstOrNull { textBounds(it).contains(point.x, point.y) }
                selectedText = textAtDown?.id
            }
            EditorTool.LASSO -> {
                val bounds = selectionBounds()?.apply { inset(-12f / viewport.scale, -12f / viewport.scale) }
                if (bounds?.contains(point.x, point.y) == true) gesture = Gesture.SELECTION
                else {
                    clearSelection()
                    gesture = Gesture.LASSO
                    lasso += point
                }
            }
            EditorTool.LINE, EditorTool.RECTANGLE, EditorTool.ELLIPSE -> {
                gesture = Gesture.SHAPE
                shapeEnd = point
            }
            EditorTool.HAND -> Unit
        }
        invalidate()
    }

    private fun updateGesture(event: MotionEvent, index: Int) {
        val x = event.getX(index); val y = event.getY(index)
        if (hypot(x - downX, y - downY) > touchSlop) moved = true
        when (gesture) {
            Gesture.INK -> addInputs(event, index)
            Gesture.ERASE -> {
                for (h in 0 until event.historySize) erase(pagePoint(event.getHistoricalX(index, h), event.getHistoricalY(index, h)))
                erase(pagePoint(x, y))
            }
            Gesture.PAN -> viewport.move(x - previousX, y - previousY)
            Gesture.LASSO -> {
                val point = pagePoint(x, y)
                if (lasso.isEmpty() || hypot(point.x - lasso.last().x, point.y - lasso.last().y) * viewport.scale >= 4f) {
                    lasso += point
                    if (lasso.size > 512) {
                        val sparse = lasso.filterIndexed { i, _ -> i % 2 == 0 }
                        lasso.clear(); lasso.addAll(sparse)
                    }
                }
            }
            Gesture.SELECTION -> {
                val offset = constrainSelectionOffset((x - downX) / viewport.scale, (y - downY) / viewport.scale)
                selectionDx = offset.x; selectionDy = offset.y
            }
            Gesture.SHAPE -> shapeEnd = constrainedPoint(pagePoint(x, y))
            Gesture.TEXT -> if (moved) textAtDown?.let { original ->
                val dx = (x - downX) / viewport.scale
                val dy = (y - downY) / viewport.scale
                val changed = if (resizeText) original.copy(width = original.width + dx) else original.copy(x = original.x + dx, y = original.y + dy)
                val current = content ?: return
                content = current.copy(textBoxes = current.textBoxes.map { if (it.id == original.id) constrainBox(changed) else it })
            }
            else -> Unit
        }
        previousX = x; previousY = y
        invalidate()
    }

    private fun addInputs(event: MotionEvent, index: Int) {
        val active = progress ?: return
        pendingInputs.clear()
        fun append(x: Float, y: Float, time: Long, pressure: Float) {
            // Finite pages clip off-page motion; drafts retain all world coordinates.
            val px = viewport.pageX(x)
            val py = viewport.pageY(y)
            val elapsed = (time - strokeStart).coerceAtLeast(0L)
            if (!InfiniteCanvas.validCoordinate(px) || !InfiniteCanvas.validCoordinate(py) || elapsed < lastInputTime || (elapsed == lastInputTime && px == lastInputX && py == lastInputY)) return
            pendingInputs.add(
                if (activeStylus) InputToolType.STYLUS else InputToolType.TOUCH,
                px, py, elapsed,
                pressure = if (activeStylus) (if (pressure.isFinite()) pressure else 0.5f).coerceIn(0f, 1f) else StrokeInput.NO_PRESSURE,
            )
            lastInputX = px; lastInputY = py; lastInputTime = elapsed
        }
        for (h in 0 until event.historySize) append(event.getHistoricalX(index, h), event.getHistoricalY(index, h), event.getHistoricalEventTime(h), event.getHistoricalPressure(index, h))
        append(event.getX(index), event.getY(index), event.eventTime, event.getPressure(index))
        if (!pendingInputs.isEmpty()) {
            active.enqueueInputs(pendingInputs, ImmutableStrokeInputBatch.EMPTY)
            active.updateShape()
        }
        postInvalidateOnAnimation()
    }

    private fun erase(point: PointF) {
        val current = content ?: return
        val previous = erasePoint ?: point
        val sweep = ImmutableParallelogram.fromSegmentAndPadding(
            ImmutableSegment(ImmutableVec(previous.x, previous.y), ImmutableVec(point.x, point.y)), eraserRadius(),
        )
        val retained = current.strokes.filterNot { cachedStroke(it).shape.intersects(sweep, AffineTransform.IDENTITY) }
        if (retained.size != current.strokes.size) content = current.copy(strokes = retained)
        erasePoint = point
    }

    private fun finishGesture() {
        val current = content ?: return
        if (gesture == Gesture.INK) progress?.let { active ->
            active.finishInput()
            active.updateShape()
            val stroke = active.toImmutable()
            if (!stroke.inputs.isEmpty()) {
                val entity = StrokeEntity(pageId = current.page.id, position = (current.strokes.maxOfOrNull { it.position } ?: -1) + 1, brush = activeBrush, color = activeColor, size = activeSize, inputs = InkSupport.encode(stroke.inputs))
                content = current.copy(strokes = current.strokes + entity)
                decoded[entity.id] = entity to stroke
            }
        }
        if (gesture == Gesture.SHAPE) shapeEnd?.let { end ->
            InkEditing.shape(current.page, settings.tool, pagePoint(downX, downY), end, settings,
                (current.strokes.maxOfOrNull { it.position } ?: -1) + 1)?.let { entity ->
                content = current.copy(strokes = current.strokes + entity)
            }
        }
        if (gesture == Gesture.LASSO) {
            selectedStrokes.addAll(current.strokes.filter { InkEditing.selected(cachedStroke(it), lasso) }.map { it.id })
            onSelectionChanged?.invoke(hasSelection)
        }
        if (gesture == Gesture.SELECTION && (selectionDx != 0f || selectionDy != 0f)) {
            content = current.copy(strokes = current.strokes.map {
                if (it.id in selectedStrokes) InkEditing.transform(it, cachedStroke(it), selectionDx, selectionDy) else it
            })
        }
        val requestText = gesture == Gesture.TEXT && !moved
        val tappedBox = textAtDown
        val tapPosition = pagePoint(downX, downY)
        val before = gestureBefore
        resetGesture()
        if (before != null && before != content) {
            history.record(before)
            publish()
        }
        if (requestText) {
            val page = current.page
            val box = tappedBox ?: TextBoxEntity(
                pageId = page.id,
                position = (current.textBoxes.maxOfOrNull { it.position } ?: -1) + 1,
                text = "", x = tapPosition.x, y = tapPosition.y,
                color = settings.color or 0xFF000000L,
            )
            onTextRequested?.invoke(constrainBox(box))
        }
        invalidate()
    }

    private fun cancelGesture() {
        gestureBefore?.let { content = it }
        resetGesture()
        invalidate()
    }

    private fun resetGesture() {
        gesture = Gesture.NONE
        gestureBefore = null
        progress = null
        activePointer = -1
        activeStylus = false
        erasePoint = null
        textAtDown = null
        previousSpan = 0f
        lasso.clear()
        shapeEnd = null
        selectionDx = 0f; selectionDy = 0f
    }

    fun undo() {
        cancelGesture()
        val current = content ?: return
        history.undo(current)?.let { content = it; selectedText = null; clearSelection(); publish() }
    }

    fun redo() {
        cancelGesture()
        val current = content ?: return
        history.redo(current)?.let { content = it; selectedText = null; clearSelection(); publish() }
    }

    fun copySelection() {
        cancelGesture()
        val current = content ?: return
        if (!hasSelection) return
        val distance = 20f / viewport.scale
        var offset = constrainSelectionOffset(distance, distance)
        if (offset.x == 0f && offset.y == 0f) offset = constrainSelectionOffset(-distance, -distance)
        val copies = current.strokes.filter { it.id in selectedStrokes }.mapIndexed { index, entity ->
            InkEditing.transform(entity, cachedStroke(entity), offset.x, offset.y).copy(
                id = newId(), position = (current.strokes.maxOfOrNull { it.position } ?: -1) + index + 1,
            )
        }
        history.record(current)
        content = current.copy(strokes = current.strokes + copies)
        selectedStrokes.clear(); selectedStrokes.addAll(copies.map { it.id })
        publish()
    }

    fun scaleSelection(factor: Float) {
        cancelGesture()
        val current = content ?: return
        val bounds = selectionBounds() ?: return
        if (!factor.isFinite() || factor <= 0f || factor == 1f || min(bounds.width(), bounds.height()) < 0.5f && factor < 1f) return
        val limit = if (current.page.background == "infinite") {
            RectF(-InfiniteCanvas.COORDINATE_LIMIT, -InfiniteCanvas.COORDINATE_LIMIT, InfiniteCanvas.COORDINATE_LIMIT, InfiniteCanvas.COORDINATE_LIMIT)
        } else RectF(0f, 0f, current.page.width, current.page.height)
        val cx = bounds.centerX(); val cy = bounds.centerY()
        val maximum = minOf((cx - limit.left) * 2 / bounds.width(), (limit.right - cx) * 2 / bounds.width(),
            (cy - limit.top) * 2 / bounds.height(), (limit.bottom - cy) * 2 / bounds.height())
        val safeFactor = min(factor.coerceIn(0.1f, 10f), maximum)
        if (safeFactor <= 0f || factor > 1f && safeFactor <= 1f) return
        val strokes = current.strokes.map {
            if (it.id in selectedStrokes) InkEditing.transform(it, cachedStroke(it), factor = safeFactor, centerX = cx, centerY = cy) else it
        }
        history.record(current)
        content = current.copy(strokes = strokes)
        publish()
    }

    fun deleteSelection() {
        cancelGesture()
        val current = content ?: return
        if (!hasSelection) return
        history.record(current)
        content = current.copy(strokes = current.strokes.filterNot { it.id in selectedStrokes })
        clearSelection()
        publish()
    }

    private fun clearSelection() {
        selectedStrokes.clear()
        onSelectionChanged?.invoke(false)
    }

    private fun selectionBounds(): RectF? {
        var result: RectF? = null
        content?.strokes?.filter { it.id in selectedStrokes }?.forEach {
            val bounds = InkEditing.bounds(cachedStroke(it))
            if (result == null) result = bounds else result?.union(bounds)
        }
        return result
    }

    private fun constrainSelectionOffset(dx: Float, dy: Float): PointF {
        val page = content?.page ?: return PointF()
        val bounds = selectionBounds() ?: return PointF()
        val limit = if (page.background == "infinite") {
            RectF(-InfiniteCanvas.COORDINATE_LIMIT, -InfiniteCanvas.COORDINATE_LIMIT, InfiniteCanvas.COORDINATE_LIMIT, InfiniteCanvas.COORDINATE_LIMIT)
        } else RectF(0f, 0f, page.width, page.height)
        fun restrict(delta: Float, lower: Float, upper: Float) = if (lower <= upper) delta.coerceIn(lower, upper) else 0f
        return PointF(restrict(dx, limit.left - bounds.left, limit.right - bounds.right), restrict(dy, limit.top - bounds.top, limit.bottom - bounds.bottom))
    }

    private fun constrainedPoint(point: PointF): PointF {
        val page = content?.page ?: return point
        val limit = InfiniteCanvas.COORDINATE_LIMIT
        return if (page.background == "infinite") PointF(point.x.coerceIn(-limit, limit), point.y.coerceIn(-limit, limit))
        else PointF(point.x.coerceIn(0f, page.width), point.y.coerceIn(0f, page.height))
    }

    fun upsertTextBox(box: TextBoxEntity) {
        cancelGesture()
        val current = content ?: return
        if (box.pageId != current.page.id) return
        val safe = constrainBox(box)
        val exists = current.textBoxes.any { it.id == safe.id }
        val boxes = if (exists) current.textBoxes.map { if (it.id == safe.id) safe else it } else current.textBoxes + safe
        val changed = current.copy(textBoxes = boxes)
        if (changed == current) return
        history.record(current)
        content = changed
        selectedText = safe.id
        publish()
    }

    fun removeTextBox(id: String) {
        cancelGesture()
        val current = content ?: return
        if (current.textBoxes.none { it.id == id }) return
        history.record(current)
        content = current.copy(textBoxes = current.textBoxes.filterNot { it.id == id })
        selectedText = null
        publish()
    }

    private fun constrainBox(box: TextBoxEntity): TextBoxEntity {
        val page = content?.page ?: return box
        if (page.background == "infinite") return box.copy(
            x = box.x.coerceIn(-InfiniteCanvas.COORDINATE_LIMIT, InfiniteCanvas.COORDINATE_LIMIT),
            y = box.y.coerceIn(-InfiniteCanvas.COORDINATE_LIMIT, InfiniteCanvas.COORDINATE_LIMIT),
            width = box.width.coerceIn(40f, 20000f), fontSize = box.fontSize.coerceIn(8f, 96f),
        )
        val minimum = min(40f, page.width)
        val x = box.x.coerceIn(0f, max(0f, page.width - minimum))
        val size = box.fontSize.coerceIn(8f, 96f)
        return box.copy(x = x, y = box.y.coerceIn(0f, max(0f, page.height - size)), width = box.width.coerceIn(minimum, page.width - x), fontSize = size)
    }

    private fun textBounds(box: TextBoxEntity): RectF {
        val layout = DocumentRenderer.textLayout(box.text.ifEmpty { " " }, box.width, box.fontSize, box.color.toInt())
        return RectF(box.x, box.y, box.x + box.width, box.y + max(layout.height.toFloat(), box.fontSize))
    }

    private fun eraserRadius() = max(6f, 12f * resources.displayMetrics.density / viewport.scale)
    private fun pagePoint(x: Float, y: Float) = PointF(viewport.pageX(x), viewport.pageY(y))
    private fun onPage(point: PointF) = content?.page?.let {
        if (it.background == "infinite") InfiniteCanvas.validCoordinate(point.x) && InfiniteCanvas.validCoordinate(point.y)
        else point.x in 0f..it.width && point.y in 0f..it.height
    } ?: false
    private fun reportHistory() { onHistoryChanged?.invoke(history.canUndo, history.canRedo) }
    private fun publish() {
        val current = content ?: return
        decoded.keys.retainAll(current.strokes.map { it.id }.toSet() + history.retainedStrokeIds())
        onContentChanged?.invoke(current)
        selectedStrokes.retainAll(current.strokes.map { it.id }.toSet())
        onSelectionChanged?.invoke(hasSelection)
        reportHistory()
        invalidate()
    }

    override fun onDetachedFromWindow() {
        cancelGesture()
        super.onDetachedFromWindow()
    }
}
