package com.qingji.notes

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Dao
interface NoteDao {
    @Query("SELECT * FROM notebooks ORDER BY updatedAt DESC, id")
    fun observeNotebooks(): Flow<List<NotebookEntity>>

    @Query("SELECT * FROM notebooks ORDER BY updatedAt DESC, id")
    suspend fun notebooks(): List<NotebookEntity>

    @Query("SELECT * FROM notebooks WHERE id = :id")
    suspend fun notebook(id: String): NotebookEntity?

    @Query("SELECT * FROM pages WHERE notebookId = :notebookId ORDER BY position, id")
    fun observePages(notebookId: String): Flow<List<PageEntity>>

    @Query("SELECT * FROM pages WHERE notebookId = :notebookId ORDER BY position, id")
    suspend fun pages(notebookId: String): List<PageEntity>

    @Query("SELECT * FROM pages WHERE id = :id")
    suspend fun page(id: String): PageEntity?

    @Query("SELECT * FROM strokes WHERE pageId = :pageId ORDER BY position, id")
    suspend fun strokes(pageId: String): List<StrokeEntity>

    @Query("SELECT * FROM text_boxes WHERE pageId = :pageId ORDER BY position, id")
    suspend fun textBoxes(pageId: String): List<TextBoxEntity>

    @Insert
    suspend fun insertNotebook(notebook: NotebookEntity)

    @Insert
    suspend fun insertPages(pages: List<PageEntity>)

    @Insert
    suspend fun insertStrokes(strokes: List<StrokeEntity>)

    @Insert
    suspend fun insertTextBoxes(boxes: List<TextBoxEntity>)

    @Query("UPDATE notebooks SET title = :title, updatedAt = :time WHERE id = :id")
    suspend fun rename(id: String, title: String, time: Long)

    @Query("UPDATE notebooks SET updatedAt = :time WHERE id = :id")
    suspend fun touch(id: String, time: Long)

    @Query("DELETE FROM notebooks WHERE id = :id")
    suspend fun deleteNotebook(id: String)

    @Query("DELETE FROM pages WHERE id = :id")
    suspend fun deletePage(id: String)

    @Query("DELETE FROM strokes WHERE pageId = :pageId")
    suspend fun deleteStrokes(pageId: String)

    @Query("DELETE FROM text_boxes WHERE pageId = :pageId")
    suspend fun deleteTextBoxes(pageId: String)

    @Query("SELECT COUNT(*) FROM pages WHERE assetPath = :path")
    suspend fun assetReferences(path: String): Int
}

@Database(
    entities = [NotebookEntity::class, PageEntity::class, StrokeEntity::class, TextBoxEntity::class],
    version = 1,
    exportSchema = true,
)
abstract class NoteDatabase : RoomDatabase() {
    abstract fun dao(): NoteDao

    companion object {
        @Volatile private var instance: NoteDatabase? = null

        fun open(context: Context): NoteDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(context.applicationContext, NoteDatabase::class.java, "qingji.db")
                .build().also { instance = it }
        }
    }
}
