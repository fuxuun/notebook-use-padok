package com.qingji.notes

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import androidx.room.withTransaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.nio.ByteBuffer
import java.nio.charset.CodingErrorAction
import kotlin.coroutines.coroutineContext
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class NoteRepository(
    context: Context,
    private val database: NoteDatabase = NoteDatabase.open(context),
) {
    private val context = context.applicationContext
    private val dao = database.dao()
    private val renderer = DocumentRenderer(this.context)
    val notebooks: Flow<List<NotebookEntity>> = dao.observeNotebooks()

    fun observePages(notebookId: String): Flow<List<PageEntity>> = dao.observePages(notebookId)

    suspend fun createNotebook(title: String, background: String): String = withContext(Dispatchers.IO) {
        requirePaper(background)
        val notebook = NotebookEntity(title = cleanTitle(title))
        mutationLock.withLock {
            database.withTransaction {
                dao.insertNotebook(notebook)
                dao.insertPages(listOf(PageEntity(notebookId = notebook.id, position = 0, background = background)))
            }
        }
        notebook.id
    }

    suspend fun renameNotebook(id: String, title: String): Unit = withContext(Dispatchers.IO) {
        val clean = cleanTitle(title)
        mutationLock.withLock {
            requireNotNull(dao.notebook(id)) { "笔记已不存在" }
            dao.rename(id, clean, System.currentTimeMillis())
        }
    }

    suspend fun deleteNotebook(id: String): Unit = withContext(Dispatchers.IO) {
        mutationLock.withLock {
            val assets = dao.pages(id).mapNotNull { it.assetPath }.distinct()
            dao.deleteNotebook(id)
            removeUnusedAssets(assets)
        }
    }

    suspend fun loadPage(id: String): PageContent = withContext(Dispatchers.IO) {
        database.withTransaction { readPage(id) }
    }

    suspend fun savePage(content: PageContent): Unit = withContext(Dispatchers.IO) {
        validateAnnotations(content)
        mutationLock.withLock {
            database.withTransaction {
                val stored = requireNotNull(dao.page(content.page.id)) { "页面已不存在，无法保存" }
                require(stored.notebookId == content.page.notebookId) { "页面不属于这本笔记" }
                dao.deleteStrokes(stored.id)
                dao.deleteTextBoxes(stored.id)
                dao.insertStrokes(content.strokes.mapIndexed { index, stroke -> stroke.copy(position = index) })
                dao.insertTextBoxes(content.textBoxes.mapIndexed { index, box -> box.copy(position = index) })
                dao.touch(stored.notebookId, System.currentTimeMillis())
            }
        }
    }

    suspend fun appendPage(notebookId: String, background: String): PageEntity = withContext(Dispatchers.IO) {
        requirePaper(background)
        mutationLock.withLock {
            database.withTransaction {
                requireNotNull(dao.notebook(notebookId)) { "笔记已不存在" }
                val pages = dao.pages(notebookId)
                require(pages.size < MAX_PAGES) { "一本笔记最多支持 $MAX_PAGES 页" }
                val page = PageEntity(notebookId = notebookId, position = (pages.maxOfOrNull { it.position } ?: -1) + 1, background = background)
                dao.insertPages(listOf(page))
                dao.touch(notebookId, System.currentTimeMillis())
                page
            }
        }
    }

    suspend fun deletePage(id: String): Unit = withContext(Dispatchers.IO) {
        mutationLock.withLock {
            val page = requireNotNull(dao.page(id)) { "页面已不存在" }
            database.withTransaction {
                require(dao.pages(page.notebookId).size > 1) { "至少保留一页；如需删除整本笔记，请返回书架" }
                dao.deletePage(id)
                dao.touch(page.notebookId, System.currentTimeMillis())
            }
            removeUnusedAssets(listOfNotNull(page.assetPath))
        }
    }

    suspend fun importDocument(uri: Uri, onNotice: (String) -> Unit = {}): String = withContext(Dispatchers.IO) {
        mutationLock.withLock {
            val name = displayName(uri)
            val mime = context.contentResolver.getType(uri).orEmpty()
            val extension = name.substringAfterLast('.', "").lowercase()
            val officeExtension = when (mime) {
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document" -> "docx"
                "application/vnd.openxmlformats-officedocument.presentationml.presentation" -> "pptx"
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" -> "xlsx"
                else -> extension
            }
            val type = when {
                officeExtension in setOf("docx", "pptx", "xlsx") -> "office"
                extension in setOf("doc", "ppt", "xls") -> throw IllegalArgumentException("请先将旧版 Office 文件另存为 DOCX、PPTX、XLSX 或 PDF")
                extension == "pdf" || mime == "application/pdf" -> "pdf"
                extension in setOf("jpg", "jpeg", "png") || mime in setOf("image/jpeg", "image/png") -> "image"
                extension in setOf("txt", "md", "markdown") || mime in setOf("text/plain", "text/markdown", "text/x-markdown") -> "text"
                else -> throw IllegalArgumentException("请选择 PDF、JPG、PNG、TXT、Markdown、DOCX、PPTX 或 XLSX 文件")
            }
            val assets = File(context.filesDir, "assets").apply { mkdirs() }
            val file = File(assets, newId())
            val source = if (type == "office") File.createTempFile("office-source-", ".$officeExtension", context.cacheDir) else file
            var committed = false
            try {
                context.contentResolver.openInputStream(uri).use { input ->
                    requireNotNull(input) { "无法打开所选文件" }
                    source.outputStream().use { copyBounded(input, it, if (type == "text") MAX_TEXT_BYTES else MAX_SOURCE_BYTES) }
                }
                if (type == "office") {
                    val notices = OfficeImporter.convert(source, officeExtension, file)
                    require(file.length() <= MAX_SOURCE_BYTES) { "Office 转换后文件过大，请拆分后导入" }
                    onNotice(notices.joinToString("\n"))
                }
                require(file.length() > 0 || type == "text") { "文件为空" }
                val notebook = NotebookEntity(title = cleanTitle(name.substringBeforeLast('.', name).ifBlank { "导入资料" }))
                val relativePath = "assets/${file.name}"
                val pages = when (type) {
                    "pdf", "office" -> inspectPdf(file, notebook.id, relativePath)
                    "image" -> {
                        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        BitmapFactory.decodeFile(file.path, bounds)
                        require(bounds.outWidth > 0 && bounds.outHeight > 0 && bounds.outMimeType in setOf("image/png", "image/jpeg")) { "图片损坏或格式不受支持" }
                        listOf(PageEntity(notebookId = notebook.id, position = 0, background = "image", assetPath = relativePath))
                    }
                    else -> {
                        val decoder = Charsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT)
                        val text = try { decoder.decode(ByteBuffer.wrap(file.readBytes())).toString().removePrefix("\uFEFF").replace("\r\n", "\n").replace('\r', '\n') }
                        catch (error: java.nio.charset.CharacterCodingException) { throw IllegalArgumentException("文本需要使用 UTF-8 编码，请转换编码后重试", error) }
                        DocumentRenderer.paginateText(text).mapIndexed { index, part ->
                            PageEntity(notebookId = notebook.id, position = index, background = "text", assetPath = relativePath, text = part)
                        }
                    }
                }
                require(pages.size in 1..MAX_PAGES) { "文件页数超过 $MAX_PAGES 页，请拆分后导入" }
                // Decode at least the first page before publishing the new notebook.
                renderer.renderBackground(pages.first(), 256).recycle()
                coroutineContext.ensureActive()
                withContext(NonCancellable) {
                    database.withTransaction { dao.insertNotebook(notebook); dao.insertPages(pages) }
                    committed = true
                }
                notebook.id
            } finally {
                if (source !== file) source.delete()
                if (!committed) file.delete()
            }
        }
    }

    suspend fun exportPdf(notebookId: String, uri: Uri): Unit = withContext(Dispatchers.IO) {
        mutationLock.withLock {
            requireNotNull(dao.notebook(notebookId)) { "笔记已不存在" }
            val temporary = File.createTempFile("qingji-export-", ".pdf", context.cacheDir)
            try {
                val pdf = PdfDocument()
                try {
                    dao.pages(notebookId).forEachIndexed { index, page ->
                        coroutineContext.ensureActive()
                        val content = readPage(page.id)
                        val bounds = renderer.contentBounds(content)
                        val maxDimension = min(2500, (max(bounds.width(), bounds.height()) * 150f / 72f).roundToInt())
                        val bitmap = renderer.renderContent(content, maxDimension, bounds)
                        try {
                            val pdfScale = min(1f, 20000f / max(bounds.width(), bounds.height()))
                            val pdfWidth = (bounds.width() * pdfScale).roundToInt().coerceAtLeast(1)
                            val pdfHeight = (bounds.height() * pdfScale).roundToInt().coerceAtLeast(1)
                            val pdfPage = pdf.startPage(PdfDocument.PageInfo.Builder(pdfWidth, pdfHeight, index + 1).create())
                            try {
                                pdfPage.canvas.drawBitmap(bitmap, null, RectF(0f, 0f, pdfWidth.toFloat(), pdfHeight.toFloat()), Paint(Paint.FILTER_BITMAP_FLAG))
                            } finally { pdf.finishPage(pdfPage) }
                        } finally { bitmap.recycle() }
                    }
                    temporary.outputStream().use { pdf.writeTo(it) }
                } finally { pdf.close() }
                publish(temporary, uri)
            } finally { temporary.delete() }
        }
    }

    suspend fun backup(uri: Uri): Unit = withContext(Dispatchers.IO) {
        mutationLock.withLock {
            val bundles = database.withTransaction {
                dao.notebooks().map { notebook -> NotebookBundle(notebook, dao.pages(notebook.id).map { readPage(it.id) }) }
            }
            val temporary = File.createTempFile("qingji-backup-", ".zip", context.cacheDir)
            try {
                temporary.outputStream().use { BackupCodec(context).write(bundles, it) }
                publish(temporary, uri)
            } finally { temporary.delete() }
        }
    }

    suspend fun restore(uri: Uri): Int = withContext(Dispatchers.IO) {
        mutationLock.withLock {
            val staging = File(context.cacheDir, "restore-${newId()}").apply { check(mkdirs()) }
            val copied = mutableListOf<File>()
            var committed = false
            try {
                val bundles = context.contentResolver.openInputStream(uri).use { input ->
                    requireNotNull(input) { "无法打开备份文件" }
                    BackupCodec(context).read(input, staging)
                }
                val assetPaths = bundles.flatMap { it.pages }.mapNotNull { it.page.assetPath }.distinct()
                val assetMap = assetPaths.associateWith { oldPath ->
                    val target = File(File(context.filesDir, "assets").apply { mkdirs() }, newId())
                    copied += target
                    File(staging, oldPath).copyTo(target)
                    "assets/${target.name}"
                }
                val restored = bundles.map { bundle ->
                    val notebook = NotebookEntity(title = bundle.notebook.title, updatedAt = System.currentTimeMillis())
                    NotebookBundle(notebook, bundle.pages.mapIndexed { index, content ->
                        val page = content.page.copy(id = newId(), notebookId = notebook.id, position = index, assetPath = content.page.assetPath?.let { assetMap.getValue(it) })
                        PageContent(page, content.strokes.map { it.copy(id = newId(), pageId = page.id) }, content.textBoxes.map { it.copy(id = newId(), pageId = page.id) })
                    })
                }
                coroutineContext.ensureActive()
                withContext(NonCancellable) {
                    database.withTransaction {
                        restored.forEach { bundle ->
                            dao.insertNotebook(bundle.notebook)
                            dao.insertPages(bundle.pages.map { it.page })
                            bundle.pages.forEach { content -> dao.insertStrokes(content.strokes); dao.insertTextBoxes(content.textBoxes) }
                        }
                    }
                    committed = true
                }
                restored.size
            } finally {
                if (!committed) copied.forEach { it.delete() }
                staging.deleteRecursively()
            }
        }
    }

    private suspend fun readPage(id: String): PageContent = PageContent(
        requireNotNull(dao.page(id)) { "页面已不存在" }, dao.strokes(id), dao.textBoxes(id),
    )

    private suspend fun removeUnusedAssets(paths: List<String>) {
        paths.forEach { if (dao.assetReferences(it) == 0) runCatching { renderer.assetFile(it).delete() } }
    }

    private fun displayName(uri: Uri): String {
        val queried = runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0) else null
            }
        }.getOrNull()
        return queried?.takeIf { it.isNotBlank() } ?: uri.lastPathSegment?.substringAfterLast('/') ?: "导入资料"
    }

    private suspend fun publish(file: File, uri: Uri) {
        coroutineContext.ensureActive()
        context.contentResolver.openOutputStream(uri, "wt").use { output ->
            requireNotNull(output) { "无法写入所选位置" }
            file.inputStream().use { input -> copyBounded(input, output, Long.MAX_VALUE) }
            output.flush()
        }
    }

    companion object {
        const val MAX_SOURCE_BYTES = 256L * 1024 * 1024
        const val MAX_TEXT_BYTES = 2L * 1024 * 1024
        const val MAX_PAGES = 2000
        private val mutationLock = Mutex()

        private fun cleanTitle(title: String): String = title.trim().take(120).also { require(it.isNotEmpty()) { "请输入笔记名称" } }
        private fun requirePaper(background: String) = require(background in setOf("blank", "lined", "grid", "infinite")) { "纸张类型无效" }

        internal fun inspectPdf(file: File, notebookId: String, path: String): List<PageEntity> {
            try {
                ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { descriptor ->
                    PdfRenderer(descriptor).use { pdf ->
                        require(pdf.pageCount in 1..MAX_PAGES) { "PDF 页数需在 1 至 $MAX_PAGES 之间" }
                        return (0 until pdf.pageCount).map { index ->
                            pdf.openPage(index).use { page ->
                                require(page.width in 1..20000 && page.height in 1..20000) { "PDF 页面尺寸过大" }
                                PageEntity(notebookId = notebookId, position = index, width = page.width.toFloat(), height = page.height.toFloat(), background = "pdf", assetPath = path, sourcePage = index)
                            }
                        }
                    }
                }
            } catch (error: SecurityException) {
                throw IllegalArgumentException("此 PDF 受密码保护，请先解除密码后导入", error)
            } catch (error: java.io.IOException) {
                throw IllegalArgumentException("PDF 损坏或无法读取", error)
            }
        }

        internal fun validateAnnotations(content: PageContent) {
            require(content.strokes.map { it.id }.toSet().size == content.strokes.size && content.textBoxes.map { it.id }.toSet().size == content.textBoxes.size) { "批注标识重复" }
            content.strokes.forEach {
                require(it.pageId == content.page.id && it.size.isFinite() && it.size in 0.1f..128f && it.color in 0..0xFFFFFFFFL && it.inputs.isNotEmpty()) { "笔迹数据无效" }
            }
            content.textBoxes.forEach {
                require(it.pageId == content.page.id && it.text.length <= 100000 && it.x.isFinite() && it.y.isFinite() && it.width.isFinite() && it.fontSize.isFinite()) { "文字框数据无效" }
                val positionValid = if (content.page.background == "infinite") {
                    InfiniteCanvas.validCoordinate(it.x) && InfiniteCanvas.validCoordinate(it.y) && it.width in 1f..20000f
                } else it.x >= 0 && it.x < content.page.width && it.y >= 0 && it.y < content.page.height && it.width in 1f..content.page.width
                require(positionValid && it.fontSize in 6f..120f && it.color in 0..0xFFFFFFFFL) { "文字框位置或样式无效" }
            }
        }

        internal suspend fun copyBounded(input: InputStream, output: OutputStream, limit: Long): Long {
            var total = 0L
            val buffer = ByteArray(64 * 1024)
            while (true) {
                coroutineContext.ensureActive()
                val count = input.read(buffer)
                if (count < 0) break
                total += count
                require(total <= limit) { "文件过大，请拆分后再试" }
                output.write(buffer, 0, count)
            }
            return total
        }
    }
}
