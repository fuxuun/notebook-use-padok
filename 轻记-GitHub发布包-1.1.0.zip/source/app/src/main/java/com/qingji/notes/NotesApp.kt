package com.qingji.notes

import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.NoteAdd
import androidx.compose.material.icons.automirrored.rounded.Redo
import androidx.compose.material.icons.automirrored.rounded.Undo
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.listSaver
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val InkColors = listOf(0xFF25332FL, 0xFF285747L, 0xFF3869B2L, 0xFFB65056L, 0xFF9668A8L, 0xFFF0BC42L)
private val TextBoxSaver = listSaver<TextBoxEntity?, Any>(
    save = { box -> box?.let { listOf(it.id, it.pageId, it.position, it.text, it.x, it.y, it.width, it.fontSize, it.color) } ?: emptyList() },
    restore = { values -> if (values.isEmpty()) null else TextBoxEntity(values[0] as String, values[1] as String, values[2] as Int, values[3] as String, values[4] as Float, values[5] as Float, values[6] as Float, values[7] as Float, values[8] as Long) },
)

@Composable
fun NotesApp(vm: NotesViewModel = viewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    val notebooks by vm.notebooks.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    var createDialog by rememberSaveable { mutableStateOf(false) }
    var rename by remember { mutableStateOf<NotebookEntity?>(null) }
    var delete by remember { mutableStateOf<NotebookEntity?>(null) }
    var pendingExportId by rememberSaveable { mutableStateOf<String?>(null) }
    var help by rememberSaveable { mutableStateOf(false) }

    val importPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let(vm::importDocument)
    }
    val pdfPicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val id = pendingExportId
        if (uri != null && id != null) vm.exportPdf(id, uri)
        pendingExportId = null
    }
    val backupPicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        uri?.let(vm::backup)
    }
    val restorePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let(vm::restore)
    }
    val importFile = {
        importPicker.launch(arrayOf("application/pdf", "image/jpeg", "image/png", "text/*", "application/octet-stream", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/vnd.openxmlformats-officedocument.presentationml.presentation", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
    }
    val backup = {
        backupPicker.launch("轻记备份-${SimpleDateFormat("yyyyMMdd-HHmm", Locale.CHINA).format(Date())}.zip")
    }
    val restore = { restorePicker.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")) }

    LaunchedEffect(state.message) {
        state.message?.let {
            snackbar.showSnackbar(it, duration = SnackbarDuration.Long)
            vm.clearMessage()
        }
    }
    BackHandler(enabled = state.notebookId != null) { if (state.busy == null) vm.closeNotebook() }

    Scaffold(snackbarHost = { SnackbarHost(snackbar) }, containerColor = Paper) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            if (state.notebookId == null) {
                Shelf(
                    notebooks = notebooks, vm = vm,
                    onCreate = { createDialog = true }, onImport = importFile,
                    onRename = { rename = it }, onDelete = { delete = it },
                    onBackup = backup, onRestore = restore, onHelp = { help = true },
                )
            } else {
                Editor(
                    state = state, vm = vm,
                    title = notebooks.firstOrNull { it.id == state.notebookId }?.title ?: "笔记",
                    onBack = vm::closeNotebook,
                    onExport = {
                        pendingExportId = state.notebookId
                        val title = notebooks.firstOrNull { it.id == state.notebookId }?.title ?: "轻记笔记"
                        pdfPicker.launch(title.replace(Regex("[\\\\/:*?\"<>|]"), "_") + ".pdf")
                    },
                )
            }
            state.busy?.let { busy ->
                Box(
                    Modifier.fillMaxSize().background(Paper.copy(alpha = 0.76f))
                        .clickable(remember { MutableInteractionSource() }, indication = null) {},
                    contentAlignment = Alignment.Center,
                ) {
                    Surface(shape = RoundedCornerShape(24.dp), shadowElevation = 8.dp) {
                        Row(Modifier.padding(28.dp), horizontalArrangement = Arrangement.spacedBy(18.dp), verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(Modifier.size(26.dp), strokeWidth = 2.5.dp)
                            Text(busy)
                        }
                    }
                }
            }
        }
    }

    if (createDialog) NotebookDialog(onDismiss = { createDialog = false }) { title, paper ->
        createDialog = false
        vm.createNotebook(title, paper)
    }
    rename?.let { note ->
        NotebookDialog(note.title, onDismiss = { rename = null }) { title, _ ->
            rename = null
            vm.renameNotebook(note.id, title)
        }
    }
    delete?.let { note ->
        ConfirmDelete("删除「${note.title}」？", "这本笔记中的页面和批注将被删除。如需保留，请先备份。", { delete = null }) {
            delete = null
            vm.deleteNotebook(note.id)
        }
    }
    if (help) AlertDialog(
        onDismissRequest = { help = false }, title = { Text("欢迎使用轻记") },
        text = {
            Text("新建分页笔记或无限草稿本，也可导入 PDF、图片、TXT、Markdown、DOCX、PPTX、XLSX。\n\n默认触控笔书写；无笔时打开“手指书写”。套索圈选笔迹后可拖动、复制、缩放或删除；直线、矩形和圆形拖动绘制。\n\n底部可切换连续滚动和单页，点击页码直接跳转。连续模式下手指上下滑动翻页，双指缩放当前页。\n\nOffice 在本机转换为批注页面，复杂版式可能有差异；不会修改原文件。备份保存转换页面和批注，请另行保管原 Office 文件。\n\n笔记保存在本机，请定期备份。卸载应用会删除本机数据。")
        },
        confirmButton = { TextButton(onClick = { help = false }) { Text("开始记录") } },
    )
}

@Composable
private fun Shelf(
    notebooks: List<NotebookEntity>, vm: NotesViewModel,
    onCreate: () -> Unit, onImport: () -> Unit,
    onRename: (NotebookEntity) -> Unit, onDelete: (NotebookEntity) -> Unit,
    onBackup: () -> Unit, onRestore: () -> Unit, onHelp: () -> Unit,
) {
    var query by rememberSaveable { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }
    val filtered = remember(notebooks, query) { notebooks.filter { it.title.contains(query.trim(), ignoreCase = true) } }
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wide = maxWidth >= 840.dp
        Row(Modifier.fillMaxSize()) {
            if (wide) {
                Column(Modifier.width(222.dp).fillMaxHeight().background(Color(0xFFEFF3EC)).padding(24.dp)) {
                    Brand()
                    Spacer(Modifier.height(52.dp))
                    Surface(color = Color(0xFFDDE8DB), shape = RoundedCornerShape(14.dp)) {
                        Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Icon(Icons.Rounded.MenuBook, null, tint = Forest, modifier = Modifier.size(21.dp))
                            Text("全部笔记", fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.weight(1f))
                            Text("${notebooks.size}", color = Forest, fontSize = 13.sp)
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                    SideAction(Icons.Rounded.UploadFile, "导入资料", onImport)
                    Spacer(Modifier.weight(1f))
                    Text("数据与帮助", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(start = 12.dp, bottom = 10.dp))
                    SideAction(Icons.Rounded.Backup, "备份全部笔记", onBackup)
                    SideAction(Icons.Rounded.Restore, "恢复备份", onRestore)
                    SideAction(Icons.Rounded.Info, "使用说明", onHelp)
                    Spacer(Modifier.height(24.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Rounded.CloudOff, null, Modifier.size(14.dp), tint = Color(0xFF738675))
                        Text("离线记录 · 存在本机", color = Color(0xFF738675), fontSize = 11.sp)
                    }
                }
            }
            Column(Modifier.weight(1f).fillMaxHeight().padding(horizontal = if (wide) 36.dp else 20.dp)) {
                Row(Modifier.fillMaxWidth().padding(top = 28.dp, bottom = 28.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        if (!wide) Text("轻记", color = Forest, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(bottom = 7.dp))
                        Text("我的笔记", fontSize = if (wide) 30.sp else 26.sp, fontWeight = FontWeight.SemiBold)
                        Text("把想法留在纸上", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp))
                    }
                    if (wide) {
                        OutlinedButton(onClick = onImport, shape = RoundedCornerShape(12.dp)) {
                            Icon(Icons.Rounded.UploadFile, null, Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp)); Text("导入资料")
                        }
                        Spacer(Modifier.width(12.dp))
                    }
                    FilledTonalIconButton(onClick = onCreate, modifier = Modifier.size(48.dp), shape = RoundedCornerShape(14.dp)) {
                        Icon(Icons.Rounded.Add, "新建笔记")
                    }
                    if (!wide) Box {
                        IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, "更多操作") }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            MenuAction("导入资料", Icons.Rounded.UploadFile) { menu = false; onImport() }
                            MenuAction("备份全部笔记", Icons.Rounded.Backup) { menu = false; onBackup() }
                            MenuAction("恢复备份", Icons.Rounded.Restore) { menu = false; onRestore() }
                            MenuAction("使用说明", Icons.Rounded.Info) { menu = false; onHelp() }
                        }
                    }
                }
                OutlinedTextField(
                    value = query, onValueChange = { query = it }, singleLine = true,
                    placeholder = { Text("搜索笔记名称", fontSize = 14.sp) },
                    leadingIcon = { Icon(Icons.Rounded.Search, null, Modifier.size(20.dp)) },
                    trailingIcon = { if (query.isNotEmpty()) IconButton(onClick = { query = "" }) { Icon(Icons.Rounded.Close, "清空搜索") } },
                    modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Color(0xFFE0E5DC), unfocusedContainerColor = Color.White.copy(alpha = 0.65f)),
                )
                Row(Modifier.fillMaxWidth().padding(vertical = 23.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(if (query.isBlank()) "全部笔记" else "搜索结果", fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                    Text("  ${filtered.size}", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                    Spacer(Modifier.weight(1f))
                    Icon(Icons.Rounded.Schedule, null, Modifier.size(14.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.width(5.dp))
                    Text("最近修改", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (filtered.isEmpty()) {
                    Column(Modifier.fillMaxWidth().weight(1f).padding(bottom = 60.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Surface(color = Mist, shape = RoundedCornerShape(28.dp), modifier = Modifier.size(94.dp)) {
                            Box(contentAlignment = Alignment.Center) { Icon(Icons.Rounded.MenuBook, null, Modifier.size(42.dp), tint = Forest) }
                        }
                        Spacer(Modifier.height(24.dp))
                        Text(if (query.isBlank()) "从一页空白开始" else "没有找到这本笔记", fontSize = 20.sp, fontWeight = FontWeight.Medium)
                        Spacer(Modifier.height(10.dp))
                        Text(if (query.isBlank()) "写下灵感，也可以导入一份资料慢慢读。" else "换个关键词试试。", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(26.dp))
                        if (query.isBlank()) Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(onClick = onCreate, shape = RoundedCornerShape(12.dp)) { Icon(Icons.Rounded.Add, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("新建笔记") }
                            OutlinedButton(onClick = onImport, shape = RoundedCornerShape(12.dp)) { Text("导入资料") }
                        }
                    }
                } else {
                    LazyVerticalGrid(columns = GridCells.Adaptive(if (wide) 190.dp else 150.dp), horizontalArrangement = Arrangement.spacedBy(20.dp), verticalArrangement = Arrangement.spacedBy(22.dp), contentPadding = PaddingValues(bottom = 28.dp)) {
                        items(filtered, key = { it.id }) { note ->
                            NotebookCard(note, vm, onClick = { vm.openNotebook(note.id) }, onRename = { onRename(note) }, onDelete = { onDelete(note) })
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Brand() {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(11.dp)) {
        Surface(color = Forest, shape = RoundedCornerShape(12.dp), modifier = Modifier.size(40.dp)) {
            Box(contentAlignment = Alignment.Center) { Icon(Icons.Rounded.EditNote, null, tint = Color.White, modifier = Modifier.size(25.dp)) }
        }
        Column { Text("轻记", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Forest); Text("一页一念", fontSize = 10.sp, color = Color(0xFF7A897D), letterSpacing = 3.sp) }
    }
}

@Composable
private fun SideAction(icon: ImageVector, text: String, onClick: () -> Unit) {
    TextButton(onClick = onClick, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 12.dp), modifier = Modifier.fillMaxWidth()) {
        Icon(icon, null, Modifier.size(19.dp), tint = Color(0xFF657B6C))
        Spacer(Modifier.width(12.dp))
        Text(text, modifier = Modifier.weight(1f), textAlign = TextAlign.Start, color = Color(0xFF536A5D), fontSize = 13.sp)
    }
}

@Composable
private fun MenuAction(label: String, icon: ImageVector, onClick: () -> Unit) {
    DropdownMenuItem(text = { Text(label) }, leadingIcon = { Icon(icon, null, Modifier.size(20.dp)) }, onClick = onClick)
}

@Composable
private fun NotebookCard(note: NotebookEntity, vm: NotesViewModel, onClick: () -> Unit, onRename: () -> Unit, onDelete: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    val cover by produceState<Bitmap?>(null, note.id, note.updatedAt) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                val page = vm.repository.observePages(note.id).first().firstOrNull() ?: return@runCatching null
                renderThumbnail(vm, page, 440)
            }.getOrNull()
        }
    }
    Column {
        Surface(onClick = onClick, shape = RoundedCornerShape(16.dp), border = BorderStroke(1.dp, Color(0xFFE0E6DB)), color = Color.White, modifier = Modifier.fillMaxWidth().aspectRatio(0.83f)) {
            Box(Modifier.fillMaxSize().background(Color(0xFFEAEFE6)).padding(15.dp)) {
                Surface(Modifier.fillMaxSize(), color = Color.White, shadowElevation = 3.dp, shape = RoundedCornerShape(3.dp)) {
                    if (cover != null) Image(cover!!.asImageBitmap(), "打开${note.title}", contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
                    else Box(contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Description, null, Modifier.size(42.dp), tint = Color(0xFFC2D0C1)) }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 9.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f).clickable(onClick = onClick)) {
                Text(note.title, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(SimpleDateFormat("MM月dd日 HH:mm", Locale.CHINA).format(Date(note.updatedAt)), modifier = Modifier.padding(top = 4.dp), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
            }
            Box {
                IconButton(onClick = { menu = true }, modifier = Modifier.size(36.dp)) { Icon(Icons.Rounded.MoreVert, "${note.title}的操作", Modifier.size(20.dp)) }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    MenuAction("重命名", Icons.Rounded.Edit) { menu = false; onRename() }
                    MenuAction("删除", Icons.Rounded.DeleteOutline) { menu = false; onDelete() }
                }
            }
        }
    }
}

private suspend fun renderThumbnail(vm: NotesViewModel, page: PageEntity, size: Int, snapshot: PageContent? = null): Bitmap {
    val content = snapshot ?: vm.repository.loadPage(page.id)
    return vm.renderer.renderContent(content, size)
}

@Composable
private fun Editor(state: NotesUiState, vm: NotesViewModel, title: String, onBack: () -> Unit, onExport: () -> Unit) {
    var canvasView by remember { mutableStateOf<NoteCanvasView?>(null) }
    var undo by remember { mutableStateOf(false) }
    var redo by remember { mutableStateOf(false) }
    var textBox by rememberSaveable(stateSaver = TextBoxSaver) { mutableStateOf<TextBoxEntity?>(null) }
    var showPagesOverride by rememberSaveable { mutableStateOf<Boolean?>(null) }
    var addPage by remember { mutableStateOf(false) }
    var deletePage by remember { mutableStateOf(false) }
    var settingsOpen by remember { mutableStateOf(false) }
    var selectedInk by remember { mutableStateOf(false) }
    var jumpDialog by remember { mutableStateOf(false) }
    val content = state.content
    val currentIndex = state.pages.indexOfFirst { it.id == content?.page?.id }
    val infinite = content?.page?.background == "infinite"
    var continuous by rememberSaveable(state.notebookId) { mutableStateOf(state.pages.size > 1 && state.pages.any { it.background == "pdf" }) }
    val pageList = rememberLazyListState(initialFirstVisibleItemIndex = currentIndex.coerceAtLeast(0))
    val scope = rememberCoroutineScope()
    val selectPage: (PageEntity) -> Unit = { page ->
        vm.openPage(page)
    }
    LaunchedEffect(state.navigationRevision) {
        if (continuous && !infinite) {
            val target = state.pages.indexOfFirst { it.id == state.navigationPageId }
            if (target >= 0) pageList.scrollToItem(target)
        }
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wide = maxWidth >= 700.dp
        val showPages = showPagesOverride ?: wide
        Column(Modifier.fillMaxSize()) {
            Surface(color = MaterialTheme.colorScheme.surface, tonalElevation = 0.dp) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "返回书架") }
                    Column(Modifier.weight(1f).padding(start = 4.dp)) {
                        Text(title, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Row(Modifier.clickable(enabled = state.saveFailed, onClick = vm::retrySave), verticalAlignment = Alignment.CenterVertically) {
                            Icon(if (state.saveFailed) Icons.Rounded.ErrorOutline else Icons.Rounded.CheckCircle, null, Modifier.size(11.dp), tint = if (state.saveFailed) MaterialTheme.colorScheme.error else Color(0xFF7A927F))
                            Spacer(Modifier.width(4.dp))
                            Text(state.saveStatus, fontSize = 10.sp, color = if (state.saveFailed) MaterialTheme.colorScheme.error else Color(0xFF7A897D))
                        }
                    }
                    IconButton(onClick = { canvasView?.undo() }, enabled = undo) { Icon(Icons.AutoMirrored.Rounded.Undo, "撤销") }
                    IconButton(onClick = { canvasView?.redo() }, enabled = redo) { Icon(Icons.AutoMirrored.Rounded.Redo, "重做") }
                    if (wide) {
                        Spacer(Modifier.width(10.dp))
                        OutlinedButton(onClick = onExport, shape = RoundedCornerShape(11.dp)) { Icon(Icons.Rounded.FileDownload, null, Modifier.size(18.dp)); Spacer(Modifier.width(7.dp)); Text("导出 PDF") }
                    } else IconButton(onClick = onExport) { Icon(Icons.Rounded.FileDownload, "导出 PDF") }
                }
            }
            HorizontalDivider(color = Color(0xFFE3E8DE))
            Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 7.dp), horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
                ToolButton(Icons.Rounded.Edit, "钢笔", EditorTool.PEN, state.settings, vm)
                ToolButton(Icons.Rounded.Highlight, "荧光笔", EditorTool.HIGHLIGHTER, state.settings, vm)
                ToolButton(Icons.Rounded.AutoFixNormal, "整笔橡皮", EditorTool.ERASER, state.settings, vm)
                ToolButton(Icons.Rounded.TextFields, "文字", EditorTool.TEXT, state.settings, vm)
                ToolButton(Icons.Rounded.PanTool, "移动", EditorTool.HAND, state.settings, vm)
                ToolButton(Icons.Rounded.Gesture, "套索选择", EditorTool.LASSO, state.settings, vm)
                ToolButton(Icons.Rounded.ShowChart, "直线", EditorTool.LINE, state.settings, vm)
                ToolButton(Icons.Rounded.CropSquare, "矩形", EditorTool.RECTANGLE, state.settings, vm)
                ToolButton(Icons.Rounded.RadioButtonUnchecked, "圆形", EditorTool.ELLIPSE, state.settings, vm)
                if (state.settings.tool == EditorTool.LASSO && selectedInk) {
                    IconButton(onClick = { canvasView?.copySelection() }) { Icon(Icons.Rounded.ContentCopy, "复制所选笔迹") }
                    IconButton(onClick = { canvasView?.scaleSelection(0.8f) }) { Icon(Icons.Rounded.ZoomOut, "缩小所选笔迹") }
                    IconButton(onClick = { canvasView?.scaleSelection(1.25f) }) { Icon(Icons.Rounded.ZoomIn, "放大所选笔迹") }
                    IconButton(onClick = { canvasView?.deleteSelection() }) { Icon(Icons.Rounded.DeleteOutline, "删除所选笔迹") }
                }
                Box(Modifier.padding(horizontal = 10.dp).width(1.dp).height(27.dp).background(Color(0xFFDFE5DC)))
                ColorPalette(state.settings.color) { vm.setSettings(state.settings.copy(color = it)) }
                Spacer(Modifier.width(8.dp))
                Box {
                    OutlinedButton(onClick = { settingsOpen = !settingsOpen }, contentPadding = PaddingValues(horizontal = 13.dp), shape = RoundedCornerShape(10.dp)) {
                        Icon(Icons.Rounded.Tune, null, Modifier.size(17.dp)); Spacer(Modifier.width(6.dp)); Text("笔设置", fontSize = 12.sp)
                    }
                    DropdownMenu(expanded = settingsOpen, onDismissRequest = { settingsOpen = false }) {
                        Column(Modifier.width(250.dp).padding(horizontal = 18.dp, vertical = 10.dp)) {
                            Text("钢笔粗细", style = MaterialTheme.typography.labelMedium)
                            Slider(value = state.settings.penSize, onValueChange = { vm.setSettings(state.settings.copy(penSize = it)) }, valueRange = 1f..10f)
                            Text("荧光笔粗细", style = MaterialTheme.typography.labelMedium)
                            Slider(value = state.settings.highlighterSize, onValueChange = { vm.setSettings(state.settings.copy(highlighterSize = it)) }, valueRange = 8f..36f)
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text("手指书写", Modifier.weight(1f), fontSize = 13.sp)
                                Switch(checked = state.settings.fingerWriting, onCheckedChange = { vm.setSettings(state.settings.copy(fingerWriting = it)) })
                            }
                            Text("关闭时仅触控笔落墨，手指移动页面。", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
                        }
                    }
                }
            }
            HorizontalDivider(color = Color(0xFFE3E8DE))
            Row(Modifier.weight(1f).fillMaxWidth()) {
                if (showPages && wide) {
                    PageStrip(state, vm, Modifier.width(132.dp).fillMaxHeight(), selectPage)
                    VerticalDivider(color = Color(0xFFDEE5D9))
                }
                Box(Modifier.weight(1f).fillMaxHeight().background(Color(0xFFE4EAE0))) {
                    if (continuous && !infinite) {
                        ContinuousPages(state, vm, pageList,
                            onActivated = { view, pageContent, bitmap ->
                                canvasView = view
                                undo = view.canUndo; redo = view.canRedo; selectedInk = view.hasSelection
                                vm.activateVisiblePage(pageContent, bitmap)
                            },
                            onTextRequested = { textBox = it },
                            onHistoryChanged = { view, canUndo, canRedo -> if (canvasView === view) { undo = canUndo; redo = canRedo } },
                            onSelectionChanged = { view, selected -> if (canvasView === view) selectedInk = selected },
                            modifier = Modifier.fillMaxSize(),
                        )
                    } else if (content != null) {
                        AndroidView(
                            factory = { context ->
                                NoteCanvasView(context).also { view ->
                                    canvasView = view
                                    view.onContentChanged = vm::edit
                                    view.onTextRequested = { textBox = it }
                                    view.onHistoryChanged = { canUndo, canRedo -> undo = canUndo; redo = canRedo }
                                    view.onSelectionChanged = { selectedInk = it }
                                }
                            },
                            update = { view ->
                                view.isEnabled = state.busy == null
                                view.setSettings(state.settings)
                                view.setPage(content, state.background)
                            },
                            modifier = Modifier.fillMaxSize().semantics { contentDescription = "第${currentIndex + 1}页笔记画布" },
                        )
                    }
                    if (showPages && !wide) {
                        Surface(modifier = Modifier.align(Alignment.CenterStart).width(110.dp).fillMaxHeight(), shadowElevation = 6.dp) { PageStrip(state, vm, Modifier.fillMaxSize(), selectPage) }
                    }
                }
            }
            Surface(color = MaterialTheme.colorScheme.surface) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { showPagesOverride = !showPages }) { Icon(Icons.Rounded.ViewSidebar, if (showPages) "隐藏缩略图" else "显示缩略图", tint = if (showPages) Forest else MaterialTheme.colorScheme.onSurfaceVariant) }
                    IconButton(onClick = { canvasView?.fitPage() }) { Icon(Icons.Rounded.CenterFocusStrong, if (infinite) "查看全部内容" else "适合页面") }
                    if (!infinite) IconButton(onClick = {
                        continuous = !continuous
                        if (continuous) scope.launch { pageList.scrollToItem(currentIndex.coerceAtLeast(0)) }
                    }) { Icon(if (continuous) Icons.Rounded.ViewAgenda else Icons.Rounded.Description, if (continuous) "切换单页" else "连续滚动") }
                    Spacer(Modifier.weight(1f))
                    IconButton(enabled = currentIndex > 0, onClick = { selectPage(state.pages[currentIndex - 1]) }) { Icon(Icons.Rounded.ChevronLeft, "上一页") }
                    Text("${(currentIndex + 1).coerceAtLeast(0)} / ${state.pages.size}", modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable { jumpDialog = true }.padding(8.dp), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    IconButton(enabled = currentIndex >= 0 && currentIndex < state.pages.lastIndex, onClick = { selectPage(state.pages[currentIndex + 1]) }) { Icon(Icons.Rounded.ChevronRight, "下一页") }
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = { addPage = true }, enabled = !infinite) { Icon(Icons.AutoMirrored.Rounded.NoteAdd, "添加页面") }
                    IconButton(onClick = { deletePage = true }, enabled = state.pages.size > 1) { Icon(Icons.Rounded.DeleteOutline, "删除当前页") }
                }
            }
        }
    }
    if (addPage) PaperDialog(onDismiss = { addPage = false }) { paper -> addPage = false; vm.appendPage(paper) }
    if (jumpDialog) {
        var number by rememberSaveable { mutableStateOf((currentIndex + 1).toString()) }
        val target = number.toIntOrNull()
        AlertDialog(onDismissRequest = { jumpDialog = false }, title = { Text("跳转页面") }, text = {
            OutlinedTextField(value = number, onValueChange = { number = it.filter(Char::isDigit).take(5) }, label = { Text("页码（1–${state.pages.size}）") }, singleLine = true)
        }, confirmButton = { TextButton(enabled = target != null && target in 1..state.pages.size, onClick = { target?.let { selectPage(state.pages[it - 1]) }; jumpDialog = false }) { Text("跳转") } }, dismissButton = { TextButton(onClick = { jumpDialog = false }) { Text("取消") } })
    }
    if (deletePage) ConfirmDelete("删除第 ${currentIndex + 1} 页？", "这一页的内容和批注会一起删除。", { deletePage = false }) { deletePage = false; vm.deleteCurrentPage() }
    textBox?.let { box ->
        val textPage = state.pages.firstOrNull { it.id == box.pageId }
        TextBoxDialog(box, content?.textBoxes?.any { it.id == box.id } == true || box.text.isNotBlank(), if (textPage?.background == "infinite") 2000f else ((textPage?.width ?: 595f) - box.x).coerceAtLeast(1f), { textBox = null }, { updated ->
            if (canvasView?.displayedPageId == updated.pageId) canvasView?.upsertTextBox(updated)
            else vm.updateTextBox(updated)
            textBox = null
        }, {
            if (canvasView?.displayedPageId == box.pageId) canvasView?.removeTextBox(box.id)
            else vm.updateTextBox(box, delete = true)
            textBox = null
        })
    }
}

@Composable
private fun ToolButton(icon: ImageVector, label: String, tool: EditorTool, settings: EditorSettings, vm: NotesViewModel) {
    val selected = settings.tool == tool
    Surface(onClick = { vm.setSettings(settings.copy(tool = tool)) }, color = if (selected) Mist else Color.Transparent, shape = RoundedCornerShape(10.dp), modifier = Modifier.size(45.dp).semantics { contentDescription = label }) {
        Box(contentAlignment = Alignment.Center) { Icon(icon, label, Modifier.size(22.dp), tint = if (selected) Forest else Color(0xFF6F7D72)) }
    }
}

@Composable
private fun ColorPalette(selected: Long, onChange: (Long) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
        InkColors.forEachIndexed { index, color ->
            val chosen = selected == color
            Box(Modifier.size(32.dp).clip(CircleShape).border(if (chosen) 1.5.dp else 0.dp, if (chosen) Color(color) else Color.Transparent, CircleShape)
                .clickable { onChange(color) }.padding(5.dp).background(Color(color), CircleShape)
                .semantics { contentDescription = listOf("墨黑", "松绿", "蓝色", "红色", "紫色", "黄色")[index] }, contentAlignment = Alignment.Center) {
                if (chosen) Icon(Icons.Rounded.Check, null, Modifier.size(13.dp), tint = if (index == 5) Ink else Color.White)
            }
        }
    }
}

@Composable
private fun PageStrip(state: NotesUiState, vm: NotesViewModel, modifier: Modifier, onSelect: (PageEntity) -> Unit = vm::openPage) {
    Column(modifier.background(Color(0xFFF0F3EB))) {
        Text("页面", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 18.dp, vertical = 16.dp))
        LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 3.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            items(state.pages, key = { it.id }) { page ->
                val selected = page.id == state.content?.page?.id
                // Only the active thumbnail changes with edits; other pages are loaded once.
                val thumbnail by produceState<Bitmap?>(null, page.id, if (selected) state.revision else 0L) {
                    if (selected) delay(180)
                    value = withContext(Dispatchers.IO) {
                        runCatching {
                            renderThumbnail(vm, page, 260, if (selected) state.content else null)
                        }.getOrNull()
                    }
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Surface(onClick = { onSelect(page) }, color = Color.White, border = BorderStroke(if (selected) 2.dp else 1.dp, if (selected) Forest else Color(0xFFD8E1D3)), shape = RoundedCornerShape(5.dp), modifier = Modifier.fillMaxWidth().aspectRatio(page.width / page.height)) {
                        if (thumbnail != null) Image(thumbnail!!.asImageBitmap(), "跳转第${state.pages.indexOf(page) + 1}页", contentScale = ContentScale.Fit)
                        else Box(contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Description, null, tint = Color(0xFFCDD7C7), modifier = Modifier.size(20.dp)) }
                    }
                    Text("${state.pages.indexOf(page) + 1}", fontSize = 10.sp, color = if (selected) Forest else MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp))
                }
            }
        }
    }
}

@Composable
private fun NotebookDialog(initialTitle: String? = null, onDismiss: () -> Unit, onConfirm: (String, String) -> Unit) {
    var title by rememberSaveable { mutableStateOf(initialTitle.orEmpty()) }
    var paper by rememberSaveable { mutableStateOf("blank") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (initialTitle == null) "新建笔记" else "重命名笔记") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(20.dp)) {
            OutlinedTextField(value = title, onValueChange = { title = it.take(120) }, label = { Text("笔记名称") }, placeholder = { Text("未命名笔记") }, singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp))
            if (initialTitle == null) {
                Text("选择纸张", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                PaperChoices(paper) { paper = it }
                FilterChip(selected = paper == "infinite", onClick = { paper = "infinite" }, label = { Text("无限草稿本 · 向四周延伸") }, leadingIcon = { Icon(Icons.Rounded.AllInclusive, null) })
            }
        }
    }, confirmButton = { Button(onClick = { onConfirm(title, paper) }, enabled = initialTitle == null || title.isNotBlank()) { Text(if (initialTitle == null) "创建笔记" else "保存") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("取消") } })
}

@Composable
private fun PaperDialog(onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var paper by remember { mutableStateOf("blank") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("添加一页") }, text = { PaperChoices(paper) { paper = it } }, confirmButton = { Button(onClick = { onConfirm(paper) }) { Text("添加") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("取消") } })
}

@Composable
private fun PaperChoices(selected: String, onChange: (String) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
        listOf("blank" to "白纸", "lined" to "横线", "grid" to "方格").forEach { (kind, label) ->
            Column(Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).border(if (kind == selected) 2.dp else 1.dp, if (kind == selected) Forest else Color(0xFFDDE4D8), RoundedCornerShape(10.dp)).clickable { onChange(kind) }.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                androidx.compose.foundation.Canvas(Modifier.fillMaxWidth().height(66.dp).background(Color.White)) {
                    val line = Color(0xFFDDE7DB)
                    if (kind != "blank") {
                        for (n in 1..6) drawLine(line, androidx.compose.ui.geometry.Offset(0f, size.height * n / 7), androidx.compose.ui.geometry.Offset(size.width, size.height * n / 7), 1f)
                        if (kind == "grid") for (n in 1..5) drawLine(line, androidx.compose.ui.geometry.Offset(size.width * n / 6, 0f), androidx.compose.ui.geometry.Offset(size.width * n / 6, size.height), 1f)
                    }
                }
                Text(label, fontSize = 12.sp, color = if (kind == selected) Forest else MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp))
            }
        }
    }
}

@Composable
private fun ConfirmDelete(title: String, detail: String, onDismiss: () -> Unit, onConfirm: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, title = { Text(title) }, text = { Text(detail) }, confirmButton = { TextButton(onClick = onConfirm, colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)) { Text("删除") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("取消") } })
}

@Composable
private fun TextBoxDialog(box: TextBoxEntity, existing: Boolean, maxWidth: Float, onDismiss: () -> Unit, onSave: (TextBoxEntity) -> Unit, onDelete: () -> Unit) {
    var text by rememberSaveable(box.id) { mutableStateOf(box.text) }
    var fontSize by rememberSaveable(box.id) { mutableStateOf(box.fontSize) }
    var width by rememberSaveable(box.id) { mutableStateOf(box.width.coerceAtMost(maxWidth)) }
    var color by rememberSaveable(box.id) { mutableStateOf(box.color) }
    val minimumWidth = minOf(40f, maxWidth)
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (existing) "编辑文字" else "添加文字") }, text = {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(value = text, onValueChange = { text = it.take(10000) }, placeholder = { Text("写下你的想法…") }, minLines = 3, maxLines = 7, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp))
            Text("字号 ${fontSize.toInt()}", fontSize = 12.sp)
            Slider(value = fontSize.coerceIn(10f, 48f), onValueChange = { fontSize = it }, valueRange = 10f..48f)
            Text("文字框宽度 ${width.toInt()}", fontSize = 12.sp)
            if (maxWidth > minimumWidth) Slider(value = width.coerceIn(minimumWidth, maxWidth), onValueChange = { width = it }, valueRange = minimumWidth..maxWidth)
            ColorPalette(color) { color = it }
            if (existing) TextButton(onClick = onDelete, colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)) { Icon(Icons.Rounded.DeleteOutline, null, Modifier.size(17.dp)); Spacer(Modifier.width(5.dp)); Text("删除文字框") }
        }
    }, confirmButton = { Button(onClick = { onSave(box.copy(text = text, fontSize = fontSize, width = width, color = color)) }, enabled = text.isNotBlank()) { Text("保存") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("取消") } })
}
