package com.qingji.notes

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

data class NotesUiState(
    val notebookId: String? = null,
    val pages: List<PageEntity> = emptyList(),
    val content: PageContent? = null,
    val background: Bitmap? = null,
    val settings: EditorSettings = EditorSettings(),
    val busy: String? = null,
    val saveStatus: String = "已保存到设备",
    val saveFailed: Boolean = false,
    val message: String? = null,
    val revision: Long = 0,
    val pageRevisions: Map<String, Long> = emptyMap(),
    val navigationRevision: Long = 0,
    val navigationPageId: String? = null,
)

class NotesViewModel(application: Application, private val savedState: SavedStateHandle) : AndroidViewModel(application) {
    val repository = NoteRepository(application)
    val renderer = DocumentRenderer(application)
    val notebooks = repository.notebooks.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    private val mutableState = MutableStateFlow(NotesUiState())
    val state = mutableState.asStateFlow()
    private val operations = Mutex()
    private val saveSignals = Channel<Unit>(Channel.CONFLATED)
    private data class Pending(val revision: Long, val content: PageContent)
    private val dirty = linkedMapOf<String, Pending>()
    private var revision = 0L
    private var pagesJob: Job? = null

    init {
        viewModelScope.launch {
            for (signal in saveSignals) {
                operations.withLock { savePending() }
            }
        }
        savedState.get<String>("notebookId")?.let(::openNotebook)
    }

    fun edit(content: PageContent) {
        if (content.page.notebookId != state.value.notebookId) return
        val currentRevision = ++revision
        dirty[content.page.id] = Pending(currentRevision, content)
        mutableState.update { it.copy(content = if (it.content?.page?.id == content.page.id) content else it.content, revision = currentRevision, pageRevisions = it.pageRevisions + (content.page.id to currentRevision), saveStatus = "正在保存…", saveFailed = false) }
        saveSignals.trySend(Unit)
    }

    suspend fun loadVisiblePage(id: String): PageContent {
        dirty[id]?.content?.let { return it }
        state.value.content?.takeIf { it.page.id == id }?.let { return it }
        val stored = repository.loadPage(id)
        return dirty[id]?.content ?: state.value.content?.takeIf { it.page.id == id } ?: stored
    }

    fun updateTextBox(box: TextBoxEntity, delete: Boolean = false) = action("正在保存文字…") {
        val content = loadVisiblePage(box.pageId)
        val boxes = if (delete) content.textBoxes.filterNot { it.id == box.id }
            else if (content.textBoxes.any { it.id == box.id }) content.textBoxes.map { if (it.id == box.id) box else it }
            else content.textBoxes + box
        edit(content.copy(textBoxes = boxes))
        savePending()
    }

    fun activateVisiblePage(content: PageContent, background: Bitmap) {
        if (state.value.busy != null || content.page.notebookId != state.value.notebookId || content.page.id == state.value.content?.page?.id) return
        mutableState.update { it.copy(content = dirty[content.page.id]?.content ?: content, background = background) }
        savedState["pageId"] = content.page.id
    }

    fun retrySave() { saveSignals.trySend(Unit) }
    fun setSettings(settings: EditorSettings) { mutableState.update { it.copy(settings = settings) } }
    fun clearMessage() { mutableState.update { it.copy(message = null) } }
    fun reportError(message: String) { mutableState.update { it.copy(message = message) } }

    // A single ordered writer also gates navigation, export and backup. A failed save
    // leaves the exact snapshot in memory and keeps the current page open for retry.
    private suspend fun savePending(): Boolean {
        while (dirty.isNotEmpty()) {
            val (pageId, pending) = dirty.entries.first().let { it.key to it.value }
            mutableState.update { it.copy(saveStatus = "正在保存…") }
            try {
                repository.savePage(pending.content)
                if (dirty[pageId]?.revision == pending.revision) dirty.remove(pageId)
            } catch (error: Exception) {
                if (error is CancellationException) throw error
                mutableState.update { it.copy(saveStatus = "保存失败 · 点击重试", saveFailed = true, message = "内容仍保留在当前页面。${error.readableMessage()}") }
                return false
            }
        }
        mutableState.update { it.copy(saveStatus = "已保存到设备", saveFailed = false) }
        return true
    }

    private fun action(label: String, block: suspend () -> Unit) {
        if (state.value.busy != null) return
        mutableState.update { it.copy(busy = label) }
        viewModelScope.launch {
            try {
                operations.withLock {
                    if (savePending()) block()
                }
            } catch (error: Exception) {
                if (error is CancellationException) throw error
                mutableState.update { it.copy(message = error.readableMessage()) }
            } finally {
                mutableState.update { it.copy(busy = null) }
            }
        }
    }

    fun createNotebook(title: String, paper: String) = action("正在创建笔记…") {
        showNotebook(repository.createNotebook(title.trim().ifEmpty { "未命名笔记" }, paper))
    }

    fun openNotebook(id: String) = action("正在打开笔记…") { showNotebook(id, savedState["pageId"]) }

    private suspend fun showNotebook(id: String, preferredPage: String? = null) {
        val pages = repository.observePages(id).first()
        val page = pages.find { it.id == preferredPage } ?: pages.firstOrNull()
            ?: error("这本笔记没有可打开的页面")
        showPage(page, pages)
        savedState["notebookId"] = id
        pagesJob?.cancel()
        pagesJob = viewModelScope.launch {
            repository.observePages(id).collect { updated ->
                if (state.value.notebookId == id) mutableState.update { it.copy(pages = updated) }
            }
        }
    }

    private suspend fun showPage(page: PageEntity, pages: List<PageEntity> = state.value.pages) {
        val content = repository.loadPage(page.id)
        val background = withContext(Dispatchers.IO) { renderer.renderBackground(page) }
        mutableState.update { it.copy(notebookId = page.notebookId, pages = pages, content = content, background = background, revision = ++revision, navigationRevision = it.navigationRevision + 1, navigationPageId = page.id) }
        savedState["pageId"] = page.id
    }

    fun openPage(page: PageEntity) {
        if (page.id == state.value.content?.page?.id) return
        action("正在翻页…") { showPage(page) }
    }

    fun closeNotebook() = action("正在保存…") {
        pagesJob?.cancel()
        savedState["notebookId"] = null
        savedState["pageId"] = null
        mutableState.update { NotesUiState(settings = it.settings) }
    }

    fun renameNotebook(id: String, title: String) = action("正在重命名…") {
        require(title.isNotBlank()) { "请输入笔记名称" }
        repository.renameNotebook(id, title.trim())
    }

    fun deleteNotebook(id: String) = action("正在删除笔记…") {
        repository.deleteNotebook(id)
        if (state.value.notebookId == id) {
            pagesJob?.cancel()
            savedState["notebookId"] = null
            savedState["pageId"] = null
            mutableState.update { NotesUiState(settings = it.settings) }
        }
    }

    fun appendPage(paper: String) = action("正在添加页面…") {
        val id = requireNotNull(state.value.notebookId)
        val page = repository.appendPage(id, paper)
        val pages = repository.observePages(id).first()
        showPage(page, pages)
    }

    fun deleteCurrentPage() = action("正在删除页面…") {
        val before = state.value
        val current = requireNotNull(before.content).page
        val index = before.pages.indexOfFirst { it.id == current.id }
        repository.deletePage(current.id)
        val pages = repository.observePages(current.notebookId).first()
        showPage(pages[index.coerceIn(0, pages.lastIndex)], pages)
    }

    fun importDocument(uri: Uri) = action("正在导入资料…") {
        var notice: String? = null
        showNotebook(repository.importDocument(uri) { notice = it })
        notice?.let { message -> mutableState.update { it.copy(message = message) } }
    }

    fun exportPdf(id: String, uri: Uri) = action("正在导出 PDF…") {
        repository.exportPdf(id, uri)
        mutableState.update { it.copy(message = "PDF 已导出，包含页面上的全部笔迹和文字") }
    }

    fun backup(uri: Uri) = action("正在备份全部笔记…") {
        repository.backup(uri)
        mutableState.update { it.copy(message = "备份已保存，原文件和可编辑笔迹均已包含") }
    }

    fun restore(uri: Uri) = action("正在检查并恢复备份…") {
        val count = repository.restore(uri)
        mutableState.update { it.copy(message = "已恢复 $count 本笔记，原有笔记保持不变") }
    }

    private fun Exception.readableMessage(): String = when (this) {
        is SecurityException -> "无法访问这个文件，请重新从文件选择器选择。"
        is java.io.FileNotFoundException -> "文件已移动或无法打开，请重新选择。"
        else -> localizedMessage?.take(220)?.takeIf { it.isNotBlank() } ?: "操作未完成，请稍后重试。"
    }
}
