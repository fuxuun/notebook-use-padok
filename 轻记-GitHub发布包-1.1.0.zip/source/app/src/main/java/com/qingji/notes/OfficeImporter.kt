package com.qingji.notes

import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.StaticLayout
import android.text.TextPaint
import android.text.style.AbsoluteSizeSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.text.style.TypefaceSpan
import android.text.style.UnderlineSpan
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.Closeable
import java.io.File
import java.io.ByteArrayInputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.zip.ZipFile
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Small offline OOXML renderer. Unsupported Office features are reported, never evaluated. */
internal object OfficeImporter {
    const val FORMAT_NOTICE = "Office 已转换为可批注页面。常见文字、图片和表格会保留；复杂图表、公式、特殊字体及分页可能有差异。需要精确版式时，请先在 Office/WPS 中导出 PDF。"

    fun convert(source: File, extension: String, output: File): List<String> {
        require(extension in setOf("docx", "pptx", "xlsx")) { "请将旧版 Office 文件另存为 DOCX、PPTX 或 XLSX 后导入" }
        val notices = linkedSetOf(FORMAT_NOTICE)
        try {
            Package(source).use { pkg ->
                val pdf = PdfDocument()
                val writer = Pages(pdf)
                try {
                    when (extension) {
                        "docx" -> word(pkg, writer, notices)
                        "pptx" -> presentation(pkg, writer, notices)
                        "xlsx" -> spreadsheet(pkg, writer, notices)
                    }
                    writer.finish()
                    require(writer.count > 0) { "文件没有可导入的页面" }
                    output.outputStream().use { pdf.writeTo(it) }
                } finally { try { writer.finish() } finally { pdf.close() } }
            }
        } catch (error: Exception) {
            output.delete()
            if (error is IllegalArgumentException) throw error
            throw IllegalArgumentException("Office 文件损坏、受密码保护或格式不受支持，请先用 Office/WPS 另存后导入", error)
        }
        return notices.toList()
    }

    private class Node(val name: String, val attrs: Map<String, String>) {
        val children = mutableListOf<Node>()
        var text = ""
        fun attr(key: String, fallback: String = "") = attrs[key] ?: fallback
        fun number(key: String, fallback: Float = 0f): Float = attrs[key]?.toFloatOrNull()?.takeIf { it.isFinite() } ?: fallback
        fun child(name: String) = children.firstOrNull { it.name == name }
        fun all(name: String): List<Node> = buildList {
            children.forEach { if (it.name == name) add(it); addAll(it.all(name)) }
        }
        fun first(name: String): Node? = children.firstOrNull { it.name == name } ?: children.firstNotNullOfOrNull { it.first(name) }
        fun texts(): String = if (name == "t") text else children.joinToString("") { it.texts() }
    }

    private class Package(file: File) : Closeable {
        private val zip = ZipFile(file)
        private var readBytes = 0L
        init {
            try {
                require(zip.size() in 1..10000) { "Office 压缩包内容过多" }
                var declared = 0L
                val names = hashSetOf<String>()
                zip.entries().asSequence().forEach {
                    require(names.add(it.name)) { "Office 压缩包包含重复文件" }
                    require(it.size <= 32L * 1024 * 1024) { "Office 文件内部资源过大" }
                    declared += max(0L, it.size)
                    require(declared <= 256L * 1024 * 1024) { "Office 文件解压后过大" }
                }
            } catch (error: Exception) { zip.close(); throw error }
        }
        fun bytes(path: String): ByteArray? {
            val entry = zip.getEntry(path) ?: return null
            require(!entry.isDirectory) { "Office 文件内部路径无效" }
            return zip.getInputStream(entry).use { input ->
                val out = java.io.ByteArrayOutputStream()
                val buffer = ByteArray(8192)
                while (true) {
                    val n = input.read(buffer)
                    if (n < 0) break
                    readBytes += n
                    require(out.size() + n <= 32 * 1024 * 1024 && readBytes <= 512L * 1024 * 1024) { "Office 文件解压内容过多" }
                    out.write(buffer, 0, n)
                }
                out.toByteArray()
            }
        }
        fun xml(path: String): Node? {
            val bytes = bytes(path) ?: return null
            require(bytes.size <= 12 * 1024 * 1024) { "Office 文档结构过大，请拆分后导入" }
            val parser = Xml.newPullParser()
            parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, true)
            parser.setFeature(XmlPullParser.FEATURE_PROCESS_DOCDECL, false)
            parser.setInput(ByteArrayInputStream(bytes), null)
            val root = Node("root", emptyMap())
            val stack = ArrayDeque<Node>().apply { addLast(root) }
            var count = 0
            while (parser.eventType != XmlPullParser.END_DOCUMENT) {
                when (parser.eventType) {
                    XmlPullParser.DOCDECL -> error("Office XML 不允许外部实体或文档类型声明")
                    XmlPullParser.START_TAG -> {
                        require(++count <= 300000 && stack.size < 100) { "Office 文档结构过于复杂" }
                        val attributes = buildMap {
                            for (index in 0 until parser.attributeCount) {
                                put(parser.getAttributeName(index), parser.getAttributeValue(index))
                                parser.getAttributePrefix(index)?.takeIf { it.isNotEmpty() }?.let { prefix ->
                                    put("$prefix:${parser.getAttributeName(index)}", parser.getAttributeValue(index))
                                }
                            }
                        }
                        val node = Node(parser.name, attributes)
                        stack.last().children += node
                        stack.addLast(node)
                    }
                    XmlPullParser.END_TAG -> stack.removeLast()
                    XmlPullParser.TEXT, XmlPullParser.CDSECT -> stack.last().let { it.text += parser.text }
                    XmlPullParser.ENTITY_REF -> {
                        require(parser.name in setOf("amp", "lt", "gt", "apos", "quot") || parser.name.startsWith('#')) { "Office XML 不允许自定义实体引用" }
                        stack.last().text += parser.text.orEmpty()
                    }
                }
                parser.nextToken()
            }
            return root.children.firstOrNull()
        }
        fun relationships(part: String): Map<String, String> {
            val folder = part.substringBeforeLast('/', "")
            val relPath = (if (folder.isEmpty()) "" else "$folder/") + "_rels/" + part.substringAfterLast('/') + ".rels"
            return xml(relPath)?.children.orEmpty().filter { it.name == "Relationship" && it.attr("TargetMode") != "External" }
                .associate { it.attr("Id") to resolve(part, it.attr("Target")) }
        }
        fun related(part: String, suffix: String): String? {
            val folder = part.substringBeforeLast('/', "")
            val relPath = (if (folder.isEmpty()) "" else "$folder/") + "_rels/" + part.substringAfterLast('/') + ".rels"
            return xml(relPath)?.children?.firstOrNull { it.attr("Type").endsWith(suffix) && it.attr("TargetMode") != "External" }
                ?.let { resolve(part, it.attr("Target")) }
        }
        override fun close() = zip.close()
    }

    private fun resolve(part: String, target: String): String {
        require(!target.contains('\\') && !target.contains(':')) { "Office 资源路径无效" }
        val segments = ArrayDeque<String>()
        if (!target.startsWith('/')) part.substringBeforeLast('/', "").split('/').filter { it.isNotEmpty() }.forEach(segments::addLast)
        target.split('/').forEach {
            when (it) {
                "", "." -> Unit
                ".." -> { require(segments.isNotEmpty()) { "Office 资源路径越界" }; segments.removeLast() }
                else -> segments.addLast(it)
            }
        }
        return segments.joinToString("/")
    }

    private class Pages(private val pdf: PdfDocument) {
        var count = 0; private set
        private var page: PdfDocument.Page? = null
        val canvas get() = requireNotNull(page).canvas
        fun next(width: Float, height: Float) {
            finish()
            require(++count <= 2000) { "Office 文件转换后超过 2000 页，请拆分后导入" }
            require(width in 72f..20000f && height in 72f..20000f) { "Office 页面尺寸不受支持" }
            page = pdf.startPage(PdfDocument.PageInfo.Builder(width.roundToInt(), height.roundToInt(), count).create())
            canvas.drawColor(Color.WHITE)
        }
        fun finish() { page?.let { pdf.finishPage(it) }; page = null }
    }

    private fun layout(text: CharSequence, width: Float, size: Float = 11f, alignment: Layout.Alignment = Layout.Alignment.ALIGN_NORMAL): StaticLayout {
        return StaticLayout.Builder.obtain(text, 0, text.length, TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = size; color = Color.BLACK }, width.roundToInt().coerceIn(1, 20000))
            .setAlignment(alignment).setIncludePad(false).setLineSpacing(1.5f, 1.05f).build()
    }

    private fun color(raw: String, fallback: Int = Color.BLACK): Int = try {
        if (raw.length == 6 || raw.length == 8) Color.parseColor("#$raw") else fallback
    } catch (_: IllegalArgumentException) { fallback }

    private fun styled(text: String, properties: Node?, size: Float, drawing: Boolean = false): CharSequence {
        val result = SpannableStringBuilder(text)
        if (text.isEmpty()) return result
        val actualSize = if (drawing) properties?.number("sz", size * 100f)?.div(100f) ?: size
            else properties?.child("sz")?.number("val", size * 2f)?.div(2f) ?: size
        fun span(value: Any) = result.setSpan(value, 0, result.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        span(AbsoluteSizeSpan(actualSize.coerceIn(5f, 180f).roundToInt()))
        val bold = if (drawing) properties?.attr("b") == "1" else properties?.child("b")?.attr("val", "1") in listOf("1", "true", "on")
        val italic = if (drawing) properties?.attr("i") == "1" else properties?.child("i")?.attr("val", "1") in listOf("1", "true", "on")
        if (bold || italic) span(StyleSpan((if (bold) Typeface.BOLD else 0) or (if (italic) Typeface.ITALIC else 0)))
        val underline = if (drawing) properties?.attr("u")?.let { it != "none" && it.isNotEmpty() } == true else properties?.child("u")?.attr("val", "single")?.let { it != "none" } == true
        if (underline) span(UnderlineSpan())
        val family = if (drawing) properties?.child("latin")?.attr("typeface") else properties?.child("rFonts")?.let { it.attr("ascii", it.attr("eastAsia")) }
        if (!family.isNullOrBlank()) span(TypefaceSpan(when {
            family.contains("Times", true) || family.contains("宋") -> "serif"
            family.contains("Courier", true) || family.contains("Consolas", true) -> "monospace"
            else -> "sans-serif"
        }))
        val shade = if (drawing) properties?.child("solidFill")?.child("srgbClr")?.attr("val") else properties?.child("color")?.attr("val")
        if (shade != null) span(ForegroundColorSpan(color(shade)))
        return result
    }

    private fun image(pkg: Package, path: String?, canvas: Canvas, rect: RectF, notices: MutableSet<String>) {
        if (path == null) return
        val bytes = pkg.bytes(path) ?: return
        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
        if (options.outWidth <= 0 || options.outHeight <= 0) { notices += "部分矢量图片未能显示，请用 Office/WPS 转为 PDF 后导入。"; return }
        var sample = 1
        while (max(options.outWidth, options.outHeight) / sample > 1800) sample *= 2
        val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample }) ?: return
        try { canvas.drawBitmap(bitmap, null, rect, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)) } finally { bitmap.recycle() }
    }

    private class WordFlow(val pages: Pages, val width: Float, val height: Float, val left: Float, val top: Float, val right: Float, val bottom: Float) {
        var y = top
        val available get() = width - left - right
        init { next() }
        fun next() { pages.next(width, height); y = top }
        fun reserve(height: Float) { if (y + height > this.height - bottom && y > top) next() }
        fun text(block: StaticLayout, x: Float = left) {
            var line = 0
            while (line < block.lineCount) {
                reserve(block.getLineBottom(line) - block.getLineTop(line) + 1f)
                val start = block.getLineTop(line)
                var end = line
                while (end + 1 < block.lineCount && block.getLineBottom(end + 1) - start <= height - bottom - y) end++
                val h = (block.getLineBottom(end) - start).toFloat()
                pages.canvas.save()
                pages.canvas.clipRect(x, y, x + block.width, min(y + h, height - bottom))
                pages.canvas.translate(x, y - start)
                block.draw(pages.canvas)
                pages.canvas.restore()
                y += h
                line = end + 1
                if (line < block.lineCount) next()
            }
        }
    }

    private fun word(pkg: Package, pages: Pages, notices: MutableSet<String>) {
        val document = requireNotNull(pkg.xml("word/document.xml")) { "无法读取 Word 正文" }
        val body = requireNotNull(document.child("body")) { "Word 文件没有正文" }
        val section = body.first("sectPr")
        val page = section?.child("pgSz")
        val margins = section?.child("pgMar")
        val width = (page?.number("w", 11900f) ?: 11900f) / 20f
        val height = (page?.number("h", 16840f) ?: 16840f) / 20f
        fun margin(key: String) = ((margins?.number(key, 1440f) ?: 1440f) / 20f).coerceIn(0f, min(width, height) / 3f)
        val flow = WordFlow(pages, width, height, margin("left"), margin("top"), margin("right"), margin("bottom"))
        val rels = pkg.relationships("word/document.xml")
        val styles = pkg.xml("word/styles.xml")?.all("style")?.associateBy { it.attr("styleId") }.orEmpty()
        fun blocks(nodes: List<Node>): List<Node> = nodes.flatMap { node ->
            when (node.name) {
                "sdt" -> blocks(node.child("sdtContent")?.children.orEmpty())
                "customXml" -> blocks(node.children)
                else -> listOf(node)
            }
        }
        fun paragraph(node: Node, table: Boolean = false): Pair<StaticLayout, Float> {
            val props = node.child("pPr")
            val style = styles[props?.child("pStyle")?.attr("val")]
            val defaults = style?.child("rPr")
            val text = SpannableStringBuilder()
            if (props?.child("numPr") != null) text.append("• ")
            node.all("r").forEach { run ->
                val value = buildString { run.children.forEach { when (it.name) { "t" -> append(it.text); "tab" -> append("    "); "br", "cr" -> append('\n') } } }
                text.append(styled(value, run.child("rPr") ?: defaults, 11f))
            }
            val indent = if (table) 0f else (props?.child("ind")?.number("left") ?: 0f) / 20f
            val align = when (props?.child("jc")?.attr("val") ?: style?.child("pPr")?.child("jc")?.attr("val")) {
                "center" -> Layout.Alignment.ALIGN_CENTER
                "right", "end" -> Layout.Alignment.ALIGN_OPPOSITE
                else -> Layout.Alignment.ALIGN_NORMAL
            }
            return layout(text.ifEmpty { SpannableStringBuilder(" ") }, flow.available - indent, 11f, align) to indent
        }
        blocks(body.children).forEach { block ->
            when (block.name) {
                "p" -> {
                    val properties = block.child("pPr")
                    if (properties?.child("pageBreakBefore") != null && flow.y > flow.top) flow.next()
                    flow.y += ((properties?.child("spacing")?.number("before") ?: 0f) / 20f).coerceIn(0f, 120f)
                    val (text, indent) = paragraph(block)
                    if (block.all("t").isNotEmpty() || block.all("drawing").isEmpty()) flow.text(text, flow.left + indent.coerceIn(0f, flow.available - 10f))
                    block.all("drawing").forEach { drawing ->
                        val extent = drawing.first("extent")
                        val w = (extent?.number("cx", 2540000f) ?: 2540000f) / 12700f
                        val h = (extent?.number("cy", 1905000f) ?: 1905000f) / 12700f
                        val scale = min(1f, min(flow.available / max(w, 1f), (height - flow.top - flow.bottom) / max(h, 1f)))
                        flow.reserve(h * scale)
                        image(pkg, rels[drawing.first("blip")?.attr("embed")], pages.canvas, RectF(flow.left, flow.y, flow.left + w * scale, flow.y + h * scale), notices)
                        flow.y += h * scale + 4f
                    }
                    flow.y += ((properties?.child("spacing")?.number("after", 100f) ?: 100f) / 20f).coerceIn(0f, 120f)
                    if (block.all("br").any { it.attr("type") == "page" }) flow.next()
                }
                "tbl" -> {
                    val grid = block.child("tblGrid")?.children?.filter { it.name == "gridCol" }?.map { it.number("w", 1440f).coerceAtLeast(20f) }.orEmpty()
                    block.children.filter { it.name == "tr" }.forEach { row ->
                        val cells = row.children.filter { it.name == "tc" }
                        if (cells.isEmpty()) return@forEach
                        val widths = mutableListOf<Float>()
                        var gridIndex = 0
                        cells.forEach { cell ->
                            val span = (cell.child("tcPr")?.child("gridSpan")?.number("val", 1f)?.toInt() ?: 1).coerceIn(1, 100)
                            widths += if (grid.isEmpty()) 1f else grid.drop(gridIndex).take(span).sum().coerceAtLeast(1f)
                            gridIndex += span
                        }
                        val total = widths.sum()
                        val layouts = cells.mapIndexed { index, cell ->
                            val text = SpannableStringBuilder()
                            blocks(cell.children).filter { it.name == "p" }.forEachIndexed { p, paragraph ->
                                if (p > 0) text.append('\n')
                                paragraph.all("r").forEach { run -> text.append(styled(run.texts(), run.child("rPr"), 11f)) }
                            }
                            layout(text, flow.available * widths[index] / total - 8f)
                        }
                        val rowHeight = (layouts.maxOfOrNull { it.height } ?: 14) + 8f
                        var consumed = 0f
                        while (consumed < rowHeight) {
                            flow.reserve(min(rowHeight - consumed, 24f))
                            val slice = min(rowHeight - consumed, height - flow.bottom - flow.y)
                            var x = flow.left
                            cells.forEachIndexed { index, cell ->
                                val cellWidth = flow.available * widths[index] / total
                                val rect = RectF(x, flow.y, x + cellWidth, flow.y + slice)
                                val fill = cell.child("tcPr")?.child("shd")?.attr("fill")
                                pages.canvas.drawRect(rect, Paint().apply { color = color(fill.orEmpty(), Color.WHITE) })
                                pages.canvas.drawRect(rect, Paint().apply { color = 0xFFAAAAAA.toInt(); style = Paint.Style.STROKE; strokeWidth = 0.5f })
                                pages.canvas.save(); pages.canvas.clipRect(rect); pages.canvas.translate(x + 4f, flow.y + 4f - consumed); layouts[index].draw(pages.canvas); pages.canvas.restore()
                                x += cellWidth
                            }
                            flow.y += slice; consumed += slice
                            if (consumed < rowHeight) flow.next()
                        }
                    }
                    flow.y += 6f
                }
            }
        }
        if (document.all("oMath").isNotEmpty()) notices += "数学公式可能未完整显示。"
    }

    private fun drawingText(node: Node, size: Float = 18f): CharSequence {
        val text = SpannableStringBuilder()
        node.children.filter { it.name == "p" }.forEachIndexed { index, p ->
            if (index > 0) text.append('\n')
            val defaults = p.child("pPr")?.child("defRPr")
            p.children.forEach { run ->
                when (run.name) {
                    "r", "fld" -> text.append(styled(run.child("t")?.text.orEmpty(), run.child("rPr") ?: defaults, size, true))
                    "br" -> text.append('\n')
                }
            }
        }
        return text
    }

    private fun presentation(pkg: Package, pages: Pages, notices: MutableSet<String>) {
        val presentation = requireNotNull(pkg.xml("ppt/presentation.xml")) { "无法读取 PowerPoint 演示文稿" }
        val size = presentation.child("sldSz")
        val width = (size?.number("cx", 9144000f) ?: 9144000f) / 12700f
        val height = (size?.number("cy", 6858000f) ?: 6858000f) / 12700f
        val rels = pkg.relationships("ppt/presentation.xml")
        val theme = pkg.xml("ppt/theme/theme1.xml")?.first("clrScheme")
        val scheme = theme?.children?.associate { it.name to color(it.children.firstOrNull()?.let { c -> c.attr("val", c.attr("lastClr")) }.orEmpty()) }.orEmpty()
        fun shade(fill: Node?, fallback: Int = Color.TRANSPARENT): Int = fill?.child("srgbClr")?.let { color(it.attr("val"), fallback) }
            ?: fill?.child("schemeClr")?.let { scheme[it.attr("val")] ?: fallback } ?: fallback
        fun rect(shape: Node): RectF? {
            val transform = shape.child("spPr")?.child("xfrm") ?: shape.child("xfrm") ?: return null
            val offset = transform.child("off") ?: return null
            val extent = transform.child("ext") ?: return null
            val x = offset.number("x") / 12700f; val y = offset.number("y") / 12700f
            return RectF(x, y, x + extent.number("cx") / 12700f, y + extent.number("cy") / 12700f)
        }
        fun placeholderShape(tree: Node?, target: Node): Node? {
            val candidates = tree?.all("sp").orEmpty().filter { it.first("ph") != null }
            fun type(ph: Node) = ph.attr("type", "obj").let { if (it == "ctrTitle") "title" else it }
            val index = target.attr("idx", "0")
            return candidates.firstOrNull { shape ->
                val ph = requireNotNull(shape.first("ph"))
                ph.attr("idx", "0") == index && type(ph) == type(target)
            } ?: candidates.firstOrNull { shape ->
                target.attr("idx").isNotEmpty() && shape.first("ph")?.attr("idx", "0") == index
            } ?: candidates.firstOrNull { type(requireNotNull(it.first("ph"))) == type(target) }
        }
        fun drawShape(shape: Node, canvas: Canvas, relations: Map<String, String>, inherited: Node? = null) {
            val area = rect(shape) ?: inherited?.let(::rect) ?: return
            if (area.width() <= 0 || area.height() <= 0) return
            val props = shape.child("spPr")
            canvas.save()
            val transform = props?.child("xfrm")
            canvas.rotate((transform?.number("rot") ?: 0f) / 60000f, area.centerX(), area.centerY())
            if (shape.name == "pic") image(pkg, relations[shape.first("blip")?.attr("embed")], canvas, area, notices)
            else {
                val fill = shade(props?.child("solidFill"))
                val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = fill }
                val ellipse = props?.child("prstGeom")?.attr("prst") == "ellipse"
                if (fill != Color.TRANSPARENT) { if (ellipse) canvas.drawOval(area, paint) else canvas.drawRect(area, paint) }
                props?.child("ln")?.let { line ->
                    paint.color = shade(line.child("solidFill")); paint.style = Paint.Style.STROKE; paint.strokeWidth = (line.number("w", 12700f) / 12700f).coerceIn(0.1f, 30f)
                    if (paint.color != Color.TRANSPARENT) { if (ellipse) canvas.drawOval(area, paint) else canvas.drawRect(area, paint) }
                }
                shape.child("txBody")?.let { body ->
                    val propsText = body.child("bodyPr")
                    val left = (propsText?.number("lIns", 91440f) ?: 91440f) / 12700f
                    val top = (propsText?.number("tIns", 45720f) ?: 45720f) / 12700f
                    val right = (propsText?.number("rIns", 91440f) ?: 91440f) / 12700f
                    val alignment = when (body.child("p")?.child("pPr")?.attr("algn")) { "ctr" -> Layout.Alignment.ALIGN_CENTER; "r" -> Layout.Alignment.ALIGN_OPPOSITE; else -> Layout.Alignment.ALIGN_NORMAL }
                    val text = layout(drawingText(body), area.width() - left - right, 18f, alignment)
                    val y = when (propsText?.attr("anchor")) { "ctr" -> area.top + (area.height() - text.height) / 2; "b" -> area.bottom - text.height - top; else -> area.top + top }
                    canvas.clipRect(area); canvas.translate(area.left + left, y); text.draw(canvas)
                }
                shape.first("tbl")?.let { table ->
                    val rows = table.children.filter { it.name == "tr" }
                    val columns = table.child("tblGrid")?.children?.map { it.number("w", 1f).coerceAtLeast(1f) }.orEmpty()
                    val totalW = columns.sum().coerceAtLeast(1f)
                    val totalH = rows.sumOf { it.number("h", 1f).toDouble() }.toFloat().coerceAtLeast(1f)
                    var y = area.top
                    rows.forEach { row ->
                        var x = area.left
                        val h = area.height() * row.number("h", 1f) / totalH
                        row.children.filter { it.name == "tc" }.forEachIndexed { index, cell ->
                            val w = area.width() * (columns.getOrNull(index) ?: 1f) / totalW
                            val cellRect = RectF(x, y, x + w, y + h)
                            canvas.drawRect(cellRect, Paint().apply { color = shade(cell.child("tcPr")?.child("solidFill"), Color.WHITE) })
                            canvas.drawRect(cellRect, Paint().apply { color = Color.GRAY; style = Paint.Style.STROKE; strokeWidth = 0.5f })
                            canvas.save(); canvas.clipRect(cellRect); canvas.translate(x + 3f, y + 3f)
                            layout(cell.child("txBody")?.let { drawingText(it, 12f) } ?: "", w - 6f, 12f).draw(canvas)
                            canvas.restore(); x += w
                        }
                        y += h
                    }
                }
                if (shape.first("chart") != null) notices += "演示文稿中的图表需要先转为 PDF 才能完整显示。"
            }
            canvas.restore()
        }
        presentation.child("sldIdLst")?.children.orEmpty().forEach { entry ->
            val path = rels[entry.attr("r:id", entry.attr("id"))] ?: error("幻灯片引用无效")
            val slide = requireNotNull(pkg.xml(path)) { "幻灯片内容缺失" }
            val layoutPath = pkg.related(path, "/slideLayout")
            val slideLayout = layoutPath?.let(pkg::xml)
            val masterPath = layoutPath?.let { pkg.related(it, "/slideMaster") }
            val master = masterPath?.let(pkg::xml)
            pages.next(width, height)
            val fill = slide.first("bgPr")?.child("solidFill") ?: slideLayout?.first("bgPr")?.child("solidFill") ?: master?.first("bgPr")?.child("solidFill")
            pages.canvas.drawColor(shade(fill, Color.WHITE))
            if (slide.attr("showMasterSp", "1") != "0") {
                listOf(masterPath to master, layoutPath to slideLayout).forEach { (backgroundPath, background) ->
                    if (backgroundPath != null && background != null) {
                        val backgroundRels = pkg.relationships(backgroundPath)
                        background.first("spTree")?.children.orEmpty().filter { it.first("ph") == null }.forEach { drawShape(it, pages.canvas, backgroundRels) }
                    }
                }
            }
            val relations = pkg.relationships(path)
            fun drawTree(tree: Node, canvas: Canvas) {
                tree.children.forEach { shape ->
                    if (shape.name == "grpSp") {
                        val x = shape.child("grpSpPr")?.child("xfrm")
                        if (x != null) {
                            val off = x.child("off"); val ext = x.child("ext"); val childOff = x.child("chOff"); val childExt = x.child("chExt")
                            canvas.save(); canvas.translate((off?.number("x") ?: 0f) / 12700f, (off?.number("y") ?: 0f) / 12700f)
                            canvas.scale((ext?.number("cx", 1f) ?: 1f) / (childExt?.number("cx", 1f) ?: 1f).coerceAtLeast(1f), (ext?.number("cy", 1f) ?: 1f) / (childExt?.number("cy", 1f) ?: 1f).coerceAtLeast(1f))
                            canvas.translate(-(childOff?.number("x") ?: 0f) / 12700f, -(childOff?.number("y") ?: 0f) / 12700f)
                            drawTree(shape, canvas); canvas.restore()
                        }
                    } else {
                        val placeholder = shape.first("ph")
                        val layoutShape = placeholder?.let { placeholderShape(slideLayout, it) }
                        val masterShape = placeholder?.let { placeholderShape(master, layoutShape?.first("ph") ?: it) }
                        val inherited = listOfNotNull(layoutShape, masterShape).firstOrNull { rect(it) != null }
                        drawShape(shape, canvas, relations, inherited)
                    }
                }
            }
            slide.first("spTree")?.let { drawTree(it, pages.canvas) }
        }
    }

    private data class Cell(val row: Int, val column: Int, val text: String, val style: Int)
    private data class SheetStyle(val font: Node?, val fill: Node?, val alignment: Node?, val format: String, val formatId: Int)
    private fun column(ref: String): Int {
        var result = 0
        for (c in ref.takeWhile { it.isLetter() }) result = result * 26 + c.uppercaseChar().code - 'A'.code + 1
        return (result - 1).coerceAtLeast(0)
    }

    private fun spreadsheet(pkg: Package, pages: Pages, notices: MutableSet<String>) {
        val workbook = requireNotNull(pkg.xml("xl/workbook.xml")) { "无法读取 Excel 工作簿" }
        val relations = pkg.relationships("xl/workbook.xml")
        val shared = pkg.xml("xl/sharedStrings.xml")?.children?.filter { it.name == "si" }?.map { it.texts() }.orEmpty()
        val styleRoot = pkg.xml("xl/styles.xml")
        val fonts = styleRoot?.child("fonts")?.children.orEmpty()
        val fills = styleRoot?.child("fills")?.children.orEmpty()
        val formats = styleRoot?.child("numFmts")?.children?.associate { it.attr("numFmtId") to it.attr("formatCode") }.orEmpty()
        val styles = styleRoot?.child("cellXfs")?.children.orEmpty().map {
            SheetStyle(fonts.getOrNull(it.number("fontId").toInt()), fills.getOrNull(it.number("fillId").toInt()), it.child("alignment"), formats[it.attr("numFmtId")].orEmpty(), it.number("numFmtId").toInt())
        }
        val date1904 = workbook.child("workbookPr")?.attr("date1904") == "1"
        fun numberText(raw: String, style: SheetStyle?): String {
            val value = raw.toDoubleOrNull() ?: return raw
            val code = style?.format.orEmpty().lowercase(Locale.ROOT)
            val date = (style?.formatId ?: -1) in 14..22 || (code.contains('y') && code.contains('d'))
            if (date && value in 0.0..2958465.0) {
                val day = if (date1904) value + 1462 else value
                val format = SimpleDateFormat(if ((style?.formatId ?: -1) in 18..21) "HH:mm:ss" else "yyyy-MM-dd", Locale.ROOT).apply { timeZone = TimeZone.getTimeZone("UTC") }
                return format.format(Date(((day - 25569) * 86400000).toLong()))
            }
            if (style?.formatId in listOf(9, 10) || '%' in code) return String.format(Locale.ROOT, if (style?.formatId == 9) "%.0f%%" else "%.2f%%", value * 100)
            if (style?.formatId in listOf(2, 4) || code == "0.00") return String.format(Locale.ROOT, "%.2f", value)
            return raw
        }
        workbook.child("sheets")?.children.orEmpty().forEach { sheet ->
            if (sheet.attr("state") == "hidden" || sheet.attr("state") == "veryHidden") return@forEach
            val path = relations[sheet.attr("r:id", sheet.attr("id"))] ?: error("工作表引用无效")
            val document = requireNotNull(pkg.xml(path)) { "工作表内容缺失" }
            val cells = document.child("sheetData")?.children.orEmpty().flatMap { row ->
                row.children.filter { it.name == "c" }.map { cell ->
                    val ref = cell.attr("r")
                    val rowIndex = (ref.dropWhile { it.isLetter() }.toIntOrNull() ?: row.number("r", 1f).toInt()) - 1
                    val styleIndex = cell.number("s").toInt()
                    val raw = cell.child("v")?.text.orEmpty()
                    val value = when (cell.attr("t")) {
                        "s" -> shared.getOrNull(raw.toIntOrNull() ?: -1).orEmpty()
                        "inlineStr" -> cell.child("is")?.texts().orEmpty()
                        "b" -> if (raw == "1") "TRUE" else "FALSE"
                        "str", "e" -> raw
                        else -> numberText(raw, styles.getOrNull(styleIndex))
                    }
                    Cell(rowIndex.coerceAtLeast(0), column(ref), value.ifEmpty { cell.child("f")?.let { "=${it.text}" }.orEmpty() }, styleIndex)
                }
            }
            require(cells.size <= 100000) { "Excel 单元格过多，请拆分后导入" }
            val merged = document.child("mergeCells")?.children.orEmpty().mapNotNull { merge ->
                val refs = merge.attr("ref").split(':')
                if (refs.size != 2) null else {
                    val r1 = refs[0].dropWhile { it.isLetter() }.toIntOrNull()?.minus(1) ?: return@mapNotNull null
                    val r2 = refs[1].dropWhile { it.isLetter() }.toIntOrNull()?.minus(1) ?: return@mapNotNull null
                    intArrayOf(r1, column(refs[0]), r2, column(refs[1]))
                }
            }
            val lastRow = max(cells.maxOfOrNull { it.row } ?: 0, merged.maxOfOrNull { it[2] } ?: 0)
            val lastColumn = max(cells.maxOfOrNull { it.column } ?: 0, merged.maxOfOrNull { it[3] } ?: 0)
            require(lastRow < 20000 && lastColumn < 1024) { "Excel 使用范围过大，请缩小后导入" }
            val columnWidths = FloatArray(lastColumn + 1) { 48f }
            document.child("cols")?.children.orEmpty().forEach { col ->
                val start = (col.number("min", 1f).toInt() - 1).coerceAtLeast(0)
                val end = min(lastColumn, col.number("max", 1f).toInt() - 1)
                for (index in start..end) columnWidths[index] = if (col.attr("hidden") == "1") 0f else (col.number("width", 8.43f) * 5.25f + 3.75f).coerceIn(12f, 500f)
            }
            val rowHeights = FloatArray(lastRow + 1) { 18f }
            document.child("sheetData")?.children.orEmpty().forEach { row ->
                val index = row.number("r", 1f).toInt() - 1
                if (index in rowHeights.indices) rowHeights[index] = if (row.attr("hidden") == "1") 0f else row.number("ht", 18f).coerceIn(10f, 600f)
            }
            val landscape = document.child("pageSetup")?.attr("orientation") == "landscape"
            val width = if (landscape) 842f else 595f; val height = if (landscape) 595f else 842f
            fun bands(sizes: FloatArray, limit: Float): List<IntRange> {
                val result = mutableListOf<IntRange>()
                var start = 0; var sum = 0f
                sizes.forEachIndexed { index, size ->
                    if (sum + size > limit && index > start) { result += start until index; start = index; sum = 0f }
                    sum += size
                }
                result += start..sizes.lastIndex
                return result
            }
            val rows = cells.groupBy { it.row }
            val xPositions = FloatArray(columnWidths.size + 1)
            columnWidths.forEachIndexed { i, w -> xPositions[i + 1] = xPositions[i] + w }
            val rowBands = bands(rowHeights, height - 78f)
            val columnBands = bands(columnWidths, width - 60f)
            require(rowBands.size.toLong() * columnBands.size <= 2000) { "Excel 打印分页超过 2000 页，请拆分后导入" }
            rowBands.forEach { rowBand -> columnBands.forEach { columnBand ->
                pages.next(width, height)
                pages.canvas.drawText(sheet.attr("name", "工作表"), 30f, 27f, Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 12f; color = Color.DKGRAY })
                var y = 42f
                rowBand.forEach { row ->
                    val h = rowHeights[row]
                    if (h > 0f) {
                        val rowCells = rows[row].orEmpty().associateBy { it.column }
                        columnBand.forEach { col ->
                            val w = columnWidths[col]
                            if (w <= 0f) return@forEach
                            val merge = merged.firstOrNull { row in it[0]..it[2] && col in it[1]..it[3] }
                            if (merge != null && (row != merge[0] || col != merge[1])) return@forEach
                            val x = 30f + xPositions[col] - xPositions[columnBand.first]
                            val cell = rowCells[col]
                            val style = cell?.let { styles.getOrNull(it.style) }
                            val mergedWidth = if (merge == null) w else (col..min(merge[3], columnBand.last)).sumOf { columnWidths[it].toDouble() }.toFloat()
                            val mergedHeight = if (merge == null) h else (row..min(merge[2], rowBand.last)).sumOf { rowHeights[it].toDouble() }.toFloat()
                            val rect = RectF(x, y, min(width - 30f, x + mergedWidth), min(height - 30f, y + mergedHeight))
                            val fill = style?.fill?.child("patternFill")?.child("fgColor")?.attr("rgb")
                            pages.canvas.drawRect(rect, Paint().apply { color = color(fill.orEmpty(), Color.WHITE) })
                            pages.canvas.drawRect(rect, Paint().apply { color = 0xFFB7BFC4.toInt(); this.style = Paint.Style.STROKE; strokeWidth = 0.4f })
                            val text = SpannableStringBuilder(cell?.text.orEmpty())
                            val font = style?.font
                            if (text.isNotEmpty()) {
                                fun span(value: Any) = text.setSpan(value, 0, text.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                                span(AbsoluteSizeSpan((font?.child("sz")?.number("val", 11f) ?: 11f).coerceIn(5f, 96f).roundToInt()))
                                span(ForegroundColorSpan(color(font?.child("color")?.attr("rgb").orEmpty())))
                                if (font?.child("b") != null) span(StyleSpan(Typeface.BOLD))
                            }
                            val align = when (style?.alignment?.attr("horizontal")) { "center" -> Layout.Alignment.ALIGN_CENTER; "right" -> Layout.Alignment.ALIGN_OPPOSITE; else -> Layout.Alignment.ALIGN_NORMAL }
                            val textLayout = layout(text, rect.width() - 6f, 11f, align)
                            pages.canvas.save(); pages.canvas.clipRect(rect); pages.canvas.translate(x + 3f, y + 2f); textLayout.draw(pages.canvas); pages.canvas.restore()
                        }
                    }
                    y += h
                }
            } }
            if (document.first("drawing") != null) notices += "Excel 中的图表和浮动图片未转换，请先导出 PDF 以保留它们。"
        }
        notices += "Excel 使用文件内已保存的公式结果，不重新计算公式。"
    }
}
