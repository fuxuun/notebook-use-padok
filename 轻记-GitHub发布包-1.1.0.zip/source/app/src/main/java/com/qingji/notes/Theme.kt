package com.qingji.notes

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Forest = Color(0xFF285747)
val Paper = Color(0xFFF8F8F3)
val Mist = Color(0xFFE9EFE8)
val Ink = Color(0xFF25332F)

private val Colors = lightColorScheme(
    primary = Forest,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDCEBDD),
    onPrimaryContainer = Color(0xFF183E30),
    secondary = Color(0xFF637B6C),
    secondaryContainer = Mist,
    background = Paper,
    onBackground = Ink,
    surface = Color(0xFFFEFEFA),
    onSurface = Ink,
    surfaceVariant = Color(0xFFEDF1E9),
    onSurfaceVariant = Color(0xFF627168),
    outline = Color(0xFFB5C1B7),
    outlineVariant = Color(0xFFDFE5DC),
)

@Composable
fun QingjiTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Colors, typography = Typography(), content = content)
}
