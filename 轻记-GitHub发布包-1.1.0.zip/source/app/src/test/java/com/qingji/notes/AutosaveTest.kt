package com.qingji.notes

import android.app.Application
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModelStore
import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [29])
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class AutosaveTest {
    private lateinit var vm: NotesViewModel
    private val store = ViewModelStore()

    @Before fun setup() {
        Dispatchers.setMain(StandardTestDispatcher())
        vm = NotesViewModel(ApplicationProvider.getApplicationContext<Application>(), SavedStateHandle())
        store.put("notes", vm)
    }

    @After fun cleanup() {
        store.clear()
        runBlocking { vm.repository.notebooks.first().forEach { vm.repository.deleteNotebook(it.id) } }
        Dispatchers.resetMain()
    }

    @Test fun rapidChangesAreSavedBeforeSwitchingToAnotherPage() = runTest {
        vm.createNotebook("自动保存", "blank")
        val page = awaitState { it.content != null && it.busy == null }.content!!
        val box = TextBoxEntity(pageId = page.page.id, position = 0, text = "第一版", x = 30f, y = 50f)
        vm.edit(page.copy(textBoxes = listOf(box)))
        vm.edit(page.copy(textBoxes = listOf(box.copy(text = "最后一次修改"))))
        vm.appendPage("lined")
        val next = awaitState { it.pages.size == 2 && it.busy == null }
        assertNotEquals(page.page.id, next.content!!.page.id)
        assertEquals("最后一次修改", vm.repository.loadPage(page.page.id).textBoxes.single().text)
        assertFalse(next.saveFailed)
    }

    @Test fun failedSaveKeepsPageOpenAndCorrectedContentCanBeSaved() = runTest {
        vm.createNotebook("保存失败恢复", "blank")
        val page = awaitState { it.content != null && it.busy == null }.content!!
        val invalid = TextBoxEntity(pageId = page.page.id, position = 0, text = "仍需保存的内容", x = 30f, y = 50f, width = -1f)
        vm.edit(page.copy(textBoxes = listOf(invalid)))
        awaitState { it.saveFailed }
        vm.closeNotebook()
        val blocked = awaitState { it.busy == null }
        assertEquals(page.page.id, blocked.content!!.page.id)
        assertEquals(invalid.text, blocked.content.textBoxes.single().text)
        assertTrue(vm.repository.loadPage(page.page.id).textBoxes.isEmpty())
        vm.edit(page.copy(textBoxes = listOf(invalid.copy(width = 200f))))
        vm.closeNotebook()
        awaitState { it.notebookId == null && it.busy == null }
        assertEquals(invalid.text, vm.repository.loadPage(page.page.id).textBoxes.single().text)
    }

    private suspend fun awaitState(predicate: (NotesUiState) -> Boolean): NotesUiState =
        withContext(Dispatchers.Default) { withTimeout(15_000) { vm.state.first(predicate) } }
}
