package com.qingji.notes

import org.junit.Assert.*
import org.junit.Test

class PageEditingTest {
    @Test fun zoomKeepsTheSamePagePointUnderTheFingers() {
        val view = PageViewport()
        view.fit(1000f, 800f, 595f, 842f, 20f)
        val px = view.pageX(420f)
        val py = view.pageY(270f)
        view.zoom(3f, 420f, 270f)
        assertEquals(px, view.pageX(420f), 0.0001f)
        assertEquals(py, view.pageY(270f), 0.0001f)
        view.move(80f, -30f)
        assertEquals(px, view.pageX(500f), 0.0001f)
        assertEquals(py, view.pageY(240f), 0.0001f)
    }

    @Test fun undoRestoresAllObjectsAndNewEditDiscardsRedo() {
        val page = PageEntity(notebookId = "book", position = 0)
        val original = PageContent(page, textBoxes = listOf(TextBoxEntity(pageId = page.id, position = 0, text = "原文", x = 10f, y = 20f)))
        val changed = original.copy(textBoxes = original.textBoxes.map { it.copy(text = "修改后", x = 200f) })
        val history = PageHistory()
        history.record(original)
        assertSame(original, history.undo(changed))
        assertTrue(history.canRedo)
        assertSame(changed, history.redo(original))
        assertSame(original, history.undo(changed))
        history.record(original)
        assertFalse(history.canRedo)
        history.clear()
        assertFalse(history.canUndo)
    }
}
