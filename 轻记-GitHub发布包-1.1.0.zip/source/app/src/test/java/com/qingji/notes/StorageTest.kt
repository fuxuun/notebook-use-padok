package com.qingji.notes

import android.content.Context
import android.net.Uri
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [29])
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class StorageTest {
    private lateinit var context: Context
    private lateinit var database: NoteDatabase
    private lateinit var repository: NoteRepository
    private lateinit var temporary: File

    @Before fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        database = Room.inMemoryDatabaseBuilder(context, NoteDatabase::class.java).build()
        repository = NoteRepository(context, database)
        temporary = File(context.cacheDir, "test-${newId()}").apply { mkdirs() }
    }

    @After fun tearDown() {
        database.close()
        temporary.deleteRecursively()
    }

    @Test fun savedTextIsReadByNewRepositoryAndInvalidSaveKeepsPreviousContent() = runBlocking {
        val noteId = repository.createNotebook("课堂笔记", "grid")
        val page = repository.observePages(noteId).first().single()
        val box = TextBoxEntity(pageId = page.id, position = 0, text = "保留这段中文", x = 40f, y = 50f)
        repository.savePage(PageContent(page, textBoxes = listOf(box)))

        val reopened = NoteRepository(context, database)
        assertEquals(listOf(box), reopened.loadPage(page.id).textBoxes)
        expectFailure { reopened.savePage(PageContent(page, textBoxes = listOf(box.copy(width = -1f)))) }
        assertEquals("保留这段中文", reopened.loadPage(page.id).textBoxes.single().text)
    }

    @Test fun deletingLastPageFailsButDeletingAnotherPagePreservesTheNote() = runBlocking {
        val id = repository.createNotebook("不可丢失", "blank")
        val first = repository.observePages(id).first().single()
        expectFailure { repository.deletePage(first.id) }
        val second = repository.appendPage(id, "lined")
        repository.deletePage(first.id)
        assertEquals(listOf(second), repository.observePages(id).first())
        assertEquals(id, repository.notebooks.first().single().id)
    }

    @Test fun textImportCopiesSourceAndBackupRestoresIndependentEditableNotes() = runBlocking {
        val source = File(temporary, "学习资料.md").apply { writeText("# 标题\n这是纯文本 Markdown。\n第二行内容。", Charsets.UTF_8) }
        val id = repository.importDocument(Uri.fromFile(source))
        val page = repository.observePages(id).first().single()
        val box = TextBoxEntity(pageId = page.id, position = 0, text = "我的批注", x = 30f, y = 80f)
        repository.savePage(PageContent(page, textBoxes = listOf(box)))
        source.delete()
        assertTrue(DocumentRenderer(context).assetFile(page.assetPath!!).isFile)

        val backup = File(temporary, "backup.zip")
        repository.backup(Uri.fromFile(backup))
        assertEquals(1, repository.restore(Uri.fromFile(backup)))
        val restoredNote = repository.notebooks.first().single { it.id != id }
        val restoredPage = repository.observePages(restoredNote.id).first().single()
        val restored = repository.loadPage(restoredPage.id)
        assertNotEquals(page.id, restoredPage.id)
        assertNotEquals(page.assetPath, restoredPage.assetPath)
        assertNotEquals(box.id, restored.textBoxes.single().id)
        assertEquals(page.text, restoredPage.text)
        assertEquals("我的批注", restored.textBoxes.single().text)
        repository.deleteNotebook(id)
        assertTrue(DocumentRenderer(context).assetFile(restoredPage.assetPath!!).isFile)
        assertEquals(1, repository.notebooks.first().size)
    }

    @Test fun corruptRestoreDoesNotCreateNotesOrRemoveExistingNotes() = runBlocking {
        val id = repository.createNotebook("原来的笔记", "blank")
        val corrupted = File(temporary, "broken.zip").apply { writeBytes(zipOf("manifest.json", "{broken".toByteArray())) }
        expectFailure { repository.restore(Uri.fromFile(corrupted)) }
        assertEquals(id, repository.notebooks.first().single().id)
        assertEquals(1, repository.observePages(id).first().size)
    }

    @Test fun archivePathTraversalIsRejectedBeforeWritingOutsideStaging() = runBlocking {
        val staging = File(temporary, "staging").apply { mkdirs() }
        val bytes = zipOf("../escaped.txt", byteArrayOf(1, 2, 3))
        expectFailure { BackupCodec(context).read(ByteArrayInputStream(bytes), staging) }
        assertFalse(File(temporary, "escaped.txt").exists())
    }

    @Test fun archiveMissingReferencedAssetIsRejected() = runBlocking {
        val page = PageEntity(notebookId = "n1", position = 0, background = "image", assetPath = "assets/missing")
        val manifest = """{"format":"qingji","version":1,"notebooks":[{"id":"n1","title":"资料","updatedAt":1,"pages":[{"id":"${page.id}","position":0,"width":595,"height":842,"background":"image","assetPath":"assets/missing","sourcePage":0,"text":null,"strokes":[],"textBoxes":[]}]}]}"""
        val staging = File(temporary, "missing").apply { mkdirs() }
        expectFailure { BackupCodec(context).read(ByteArrayInputStream(zipOf("manifest.json", manifest.toByteArray())), staging) }
    }

    @Test fun paginationPreservesAllCharactersAndFitsPaper() {
        val text = (1..240).joinToString("\n") { "第 $it 行：中文和 English 混排，长行应当自动换行。".repeat(4) }
        val pages = DocumentRenderer.paginateText(text)
        assertTrue(pages.size > 1)
        assertEquals(text, pages.joinToString(""))
        pages.forEach { part ->
            val layout = DocumentRenderer.textLayout(part.trimEnd('\n'), 595f - 2 * DocumentRenderer.MARGIN, DocumentRenderer.TEXT_SIZE, android.graphics.Color.BLACK, 1.35f)
            assertTrue("页面内容不应超出纸张", layout.height <= 842f - 2 * DocumentRenderer.MARGIN + 1)
        }
    }

    @Test fun rejectedImportLeavesLibraryAndAssetsUnchanged() = runBlocking {
        val assetRoot = File(context.filesDir, "assets")
        val before = assetRoot.list()?.toSet().orEmpty()
        val invalid = File(temporary, "bad.txt").apply { writeBytes(byteArrayOf(0xC3.toByte(), 0x28)) }
        expectFailure { repository.importDocument(Uri.fromFile(invalid)) }
        assertTrue(repository.notebooks.first().isEmpty())
        assertEquals(before, assetRoot.list()?.toSet().orEmpty())
    }

    private fun zipOf(name: String, content: ByteArray): ByteArray = ByteArrayOutputStream().also { bytes ->
        ZipOutputStream(bytes).use { zip -> zip.putNextEntry(ZipEntry(name)); zip.write(content); zip.closeEntry() }
    }.toByteArray()

    private suspend fun expectFailure(action: suspend () -> Unit) {
        try { action(); fail("应拒绝无效操作") }
        catch (error: IllegalArgumentException) { /* expected validation failure */ }
    }
}
