param([Parameter(ValueFromRemainingArguments = $true)][string[]]$Tasks)
$ErrorActionPreference = 'Stop'
$projectRoot = $PSScriptRoot
$localJdk = Get-ChildItem -LiteralPath (Join-Path $projectRoot '.tools') -Directory -Filter 'jdk-17*' -ErrorAction SilentlyContinue | Select-Object -First 1
if ($localJdk) { $env:JAVA_HOME = $localJdk.FullName }
elseif (Test-Path -LiteralPath (Join-Path $projectRoot '.tools/java-home.txt')) {
    $env:JAVA_HOME = (Get-Content -LiteralPath (Join-Path $projectRoot '.tools/java-home.txt') -Raw).Trim()
}
if (Test-Path -LiteralPath (Join-Path $projectRoot '.tools/android-sdk')) {
    $env:ANDROID_HOME = Join-Path $projectRoot '.tools/android-sdk'
    $env:ANDROID_USER_HOME = Join-Path $projectRoot '.tools/android-user'
}
$env:GRADLE_USER_HOME = Join-Path $projectRoot '.tools/gradle-home'
if (-not $Tasks) { $Tasks = @('testDebugUnitTest', 'lintDebug', 'assembleRelease') }
Push-Location $projectRoot
try {
    $gradle = Join-Path $projectRoot '.tools/gradle-8.13/bin/gradle.bat'
    if (-not (Test-Path -LiteralPath $gradle)) { $gradle = Join-Path $projectRoot 'gradlew.bat' }
    & $gradle @Tasks --console=plain
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
} finally { Pop-Location }
