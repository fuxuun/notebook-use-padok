# GitHub 发布材料

建议仓库名：`qingji`。

About 描述：
> 轻记 Qingji — Android 平板上的轻量离线笔记：文档批注、无限草稿、套索与几何工具，约 7.5 MB。

Topics：`android`、`kotlin`、`jetpack-compose`、`note-taking`、`handwriting`、`stylus`、`pdf-annotation`、`offline`。

1. 新建仓库并上传源码包解压后的文件，保留 `.github`、`.gitignore` 等点文件。源码包不包含工具、缓存、私有签名或本机配置。
2. Release 标签填写 `v1.1.0`，标题及正文使用 [发布说明](RELEASE-v1.1.0.md)。建议勾选 Pre-release，当前仍为体验版。
3. 将 `轻记-1.1.0.apk`、`SHA256.txt` 和使用说明上传为 Release 附件，APK 不放入源码历史。
4. 发布后可将 README 下载入口改为实际 Release 链接。真实截图或短录屏后续再加入，当前封面已明确标为插画。

Release 的附件、草稿和 Pre-release 操作见 [GitHub 官方说明](https://docs.github.com/en/repositories/releasing-projects-on-github/managing-releases-in-a-repository)。

项目已按作者选择添加 MIT 许可，版权行使用项目贡献者署名 `Qingji contributors`。后续发布应妥善保管同一签名，源码包不会包含签名密钥。
